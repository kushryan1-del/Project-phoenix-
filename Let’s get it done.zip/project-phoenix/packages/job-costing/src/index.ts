
import { z } from "zod";

export const laborEntrySchema = z.object({
  workerName: z.string().trim().min(1).max(120),
  workDate: z.string().datetime(),
  task: z.string().trim().min(2).max(300),
  regularHours: z.coerce.number().min(0).max(24),
  overtimeHours: z.coerce.number().min(0).max(24).default(0),
  hourlyCost: z.coerce.number().min(0),
  overtimeMultiplier: z.coerce.number().min(1).max(3).default(1.5),
  laborBurdenPercent: z.coerce.number().min(0).max(200).default(0),
  notes: z.string().max(2000).optional().nullable()
});

export const purchaseSchema = z.object({
  purchasedAt: z.string().datetime(),
  supplier: z.string().trim().min(1).max(160),
  description: z.string().trim().min(2).max(400),
  category: z.enum(["MATERIAL","EQUIPMENT","RENTAL","PERMIT","DISPOSAL","SUBCONTRACTOR","OTHER"]),
  subtotal: z.coerce.number().min(0),
  salesTax: z.coerce.number().min(0).default(0),
  receiptNumber: z.string().max(120).optional().nullable(),
  paymentMethod: z.enum(["CASH","CHECK","CREDIT_CARD","DEBIT_CARD","ACCOUNT","OTHER"]),
  notes: z.string().max(2000).optional().nullable()
});

export const expenseSchema = z.object({
  occurredAt: z.string().datetime(),
  description: z.string().trim().min(2).max(400),
  category: z.enum(["EQUIPMENT","PERMIT","DISPOSAL","SUBCONTRACTOR","TRAVEL","DELIVERY","OTHER"]),
  amount: z.coerce.number().min(0),
  notes: z.string().max(2000).optional().nullable()
});

export type LaborEntryInput = z.infer<typeof laborEntrySchema>;
export type PurchaseInput = z.infer<typeof purchaseSchema>;
export type ExpenseInput = z.infer<typeof expenseSchema>;

const round = (value:number) => Math.round((value + Number.EPSILON) * 100) / 100;

export function calculateLaborCost(entry:LaborEntryInput) {
  const regular = entry.regularHours * entry.hourlyCost;
  const overtime = entry.overtimeHours * entry.hourlyCost * entry.overtimeMultiplier;
  const wages = regular + overtime;
  const burden = wages * entry.laborBurdenPercent / 100;
  return {
    regularCost: round(regular),
    overtimeCost: round(overtime),
    burdenCost: round(burden),
    totalCost: round(wages + burden)
  };
}

export type JobCostingSummaryInput = {
  contractValue:number;
  approvedChangeOrders:number;
  estimatedLabor:number;
  estimatedMaterials:number;
  estimatedOther:number;
  actualLabor:number;
  actualMaterials:number;
  actualOther:number;
  invoiced:number;
  collected:number;
};

export function calculateJobCostingSummary(input:JobCostingSummaryInput) {
  const revenue = input.contractValue + input.approvedChangeOrders;
  const estimatedCost = input.estimatedLabor + input.estimatedMaterials + input.estimatedOther;
  const actualCost = input.actualLabor + input.actualMaterials + input.actualOther;
  const estimatedProfit = revenue - estimatedCost;
  const actualProfit = revenue - actualCost;
  const estimatedMargin = revenue ? estimatedProfit / revenue * 100 : 0;
  const actualMargin = revenue ? actualProfit / revenue * 100 : 0;
  const outstandingInvoices = Math.max(0,input.invoiced-input.collected);
  const unbilledRevenue = Math.max(0,revenue-input.invoiced);
  const costVariance = actualCost-estimatedCost;
  const laborVariance = input.actualLabor-input.estimatedLabor;
  const materialVariance = input.actualMaterials-input.estimatedMaterials;
  const otherVariance = input.actualOther-input.estimatedOther;

  let health:"ON_BUDGET"|"WATCH"|"OVER_BUDGET" = "ON_BUDGET";
  if(actualCost > estimatedCost * 1.1) health = "OVER_BUDGET";
  else if(actualCost > estimatedCost * .9) health = "WATCH";

  return {
    revenue:round(revenue),
    estimatedCost:round(estimatedCost),
    actualCost:round(actualCost),
    estimatedProfit:round(estimatedProfit),
    actualProfit:round(actualProfit),
    estimatedMargin:round(estimatedMargin),
    actualMargin:round(actualMargin),
    outstandingInvoices:round(outstandingInvoices),
    unbilledRevenue:round(unbilledRevenue),
    costVariance:round(costVariance),
    laborVariance:round(laborVariance),
    materialVariance:round(materialVariance),
    otherVariance:round(otherVariance),
    health
  };
}
