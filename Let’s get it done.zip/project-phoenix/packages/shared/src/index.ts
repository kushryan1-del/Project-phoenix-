import { z } from "zod";

export const taskCreateSchema = z.object({
  title:z.string().min(2), description:z.string().optional(),
  priority:z.number().int().min(1).max(3).default(2), dueAt:z.string().datetime().optional()
});

export const jobSheetCreateSchema = z.object({
  workDate:z.string().datetime(), workCompleted:z.string().min(3),
  workPlanned:z.string().optional(), materialsUsed:z.string().optional(),
  issues:z.string().optional(), weatherNotes:z.string().optional(), customerNotes:z.string().optional()
});

export const estimateLineSchema = z.object({
  type:z.enum(["LABOR","MATERIAL","EQUIPMENT","SUBCONTRACTOR","DISPOSAL","PERMIT","OTHER"]),
  description:z.string().min(2),
  quantity:z.number().positive(),
  unit:z.string().min(1),
  unitCost:z.number().nonnegative(),
  wastePercent:z.number().min(0).max(100).default(0),
  markupPercent:z.number().min(0).max(500).default(0),
  taxableMaterial:z.boolean().default(false)
});

export const estimateCreateSchema = z.object({
  estimateNumber:z.string().min(1),
  version:z.number().int().positive().default(1),
  contingencyPercent:z.number().min(0).max(100).default(0),
  materialTaxPercent:z.number().min(0).max(25).default(6),
  targetMarginPercent:z.number().min(0).max(95).optional(),
  notes:z.string().optional(),
  items:z.array(estimateLineSchema).min(1)
});

export const invoiceCreateSchema = z.object({
  invoiceNumber:z.string().min(1),
  description:z.string().min(2),
  subtotal:z.number().nonnegative(),
  materialTax:z.number().nonnegative().default(0),
  dueDate:z.string().datetime().optional()
});

export const paymentCreateSchema = z.object({
  invoiceId:z.string().optional(),
  amount:z.number().positive(),
  method:z.enum(["Cash","Check","Credit Card","ACH","Other"]),
  reference:z.string().optional(),
  paidAt:z.string().datetime(),
  notes:z.string().optional()
});

export const changeOrderCreateSchema = z.object({
  number:z.number().int().positive(),
  title:z.string().min(2),
  description:z.string().min(3),
  addedCost:z.number().nonnegative().default(0),
  addedPrice:z.number().nonnegative(),
  addedDays:z.number().int().min(0).default(0),
  materialTax:z.number().nonnegative().default(0)
});

export function roundMoney(value:number){ return Math.round((value + Number.EPSILON) * 100) / 100; }

export function calculateEstimate(input:z.infer<typeof estimateCreateSchema>) {
  const lines = input.items.map((item,index)=>{
    const orderQuantity = item.quantity * (1 + item.wastePercent / 100);
    const totalCost = roundMoney(orderQuantity * item.unitCost);
    const totalPrice = roundMoney(totalCost * (1 + item.markupPercent / 100));
    return {
      ...item,
      sortOrder:index,
      customerUnitPrice:roundMoney(totalPrice / item.quantity),
      totalCost,
      totalPrice
    };
  });

  const laborCost = roundMoney(lines.filter(x=>x.type==="LABOR").reduce((s,x)=>s+x.totalCost,0));
  const materialCost = roundMoney(lines.filter(x=>x.type==="MATERIAL").reduce((s,x)=>s+x.totalCost,0));
  const otherCost = roundMoney(lines.filter(x=>!["LABOR","MATERIAL"].includes(x.type)).reduce((s,x)=>s+x.totalCost,0));
  const materialSellingPrice = roundMoney(lines.filter(x=>x.type==="MATERIAL").reduce((s,x)=>s+x.totalPrice,0));
  const materialMarkup = roundMoney(materialSellingPrice-materialCost);
  const taxableMaterialPrice = roundMoney(lines.filter(x=>x.taxableMaterial).reduce((s,x)=>s+x.totalPrice,0));
  const materialTax = roundMoney(taxableMaterialPrice * input.materialTaxPercent / 100);
  const basePrice = roundMoney(lines.reduce((s,x)=>s+x.totalPrice,0));
  const contingency = roundMoney(basePrice * input.contingencyPercent / 100);
  const totalCost = roundMoney(laborCost+materialCost+otherCost);

  let sellingPrice = roundMoney(basePrice + contingency + materialTax);
  if(input.targetMarginPercent !== undefined) {
    const requiredBeforeTax = totalCost / (1 - input.targetMarginPercent/100);
    sellingPrice = roundMoney(Math.max(sellingPrice, requiredBeforeTax + materialTax));
  }

  const grossProfit = roundMoney(sellingPrice-materialTax-totalCost);
  const marginPercent = sellingPrice-materialTax > 0
    ? roundMoney(grossProfit/(sellingPrice-materialTax)*100)
    : 0;

  return {
    lines, laborCost, materialCost, otherCost, materialMarkup,
    materialTax, contingency, totalCost, sellingPrice, grossProfit, marginPercent
  };
}
