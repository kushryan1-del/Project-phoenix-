CREATE TYPE "CrmActivityType" AS ENUM ('CALL','EMAIL','TEXT','MEETING','SITE_VISIT','NOTE','FOLLOW_UP');
CREATE TABLE "CrmActivity" (
  "id" TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "customerId" TEXT,
  "leadId" TEXT,
  "actorId" TEXT,
  "type" "CrmActivityType" NOT NULL,
  "summary" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "CrmActivity_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "CrmActivity_organizationId_createdAt_idx" ON "CrmActivity"("organizationId","createdAt");
CREATE INDEX "CrmActivity_customerId_createdAt_idx" ON "CrmActivity"("customerId","createdAt");
CREATE INDEX "CrmActivity_leadId_createdAt_idx" ON "CrmActivity"("leadId","createdAt");
ALTER TABLE "CrmActivity" ADD CONSTRAINT "CrmActivity_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "CrmActivity" ADD CONSTRAINT "CrmActivity_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "CrmActivity" ADD CONSTRAINT "CrmActivity_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES "Lead"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "CrmActivity" ADD CONSTRAINT "CrmActivity_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
