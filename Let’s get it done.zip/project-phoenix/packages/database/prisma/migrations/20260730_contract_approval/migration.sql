ALTER TABLE "Contract"
  ADD COLUMN "customerSignedName" TEXT,
  ADD COLUMN "customerSignedEmail" TEXT,
  ADD COLUMN "customerAcceptedIp" TEXT,
  ADD COLUMN "customerAcceptedUserAgent" TEXT;

CREATE TABLE "ContractApprovalToken" (
  "id" TEXT NOT NULL,
  "projectId" TEXT NOT NULL,
  "contractId" TEXT NOT NULL,
  "tokenHash" TEXT NOT NULL,
  "expiresAt" TIMESTAMP(3) NOT NULL,
  "usedAt" TIMESTAMP(3),
  "revokedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ContractApprovalToken_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "ContractApprovalToken_tokenHash_key" ON "ContractApprovalToken"("tokenHash");
CREATE INDEX "ContractApprovalToken_contractId_expiresAt_idx" ON "ContractApprovalToken"("contractId", "expiresAt");
CREATE INDEX "ContractApprovalToken_projectId_expiresAt_idx" ON "ContractApprovalToken"("projectId", "expiresAt");
ALTER TABLE "ContractApprovalToken" ADD CONSTRAINT "ContractApprovalToken_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "Project"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ContractApprovalToken" ADD CONSTRAINT "ContractApprovalToken_contractId_fkey" FOREIGN KEY ("contractId") REFERENCES "Contract"("id") ON DELETE CASCADE ON UPDATE CASCADE;
