-- Project Phoenix Version 1.0 authentication foundation
ALTER TABLE "User" ADD COLUMN "passwordHash" TEXT;
ALTER TABLE "User" ADD COLUMN "isActive" BOOLEAN NOT NULL DEFAULT true;
ALTER TABLE "User" ADD COLUMN "lastLoginAt" TIMESTAMP(3);
ALTER TABLE "User" ADD COLUMN "failedLoginCount" INTEGER NOT NULL DEFAULT 0;
ALTER TABLE "User" ADD COLUMN "lockedUntil" TIMESTAMP(3);

-- AuthSession, PasswordResetToken, AuditEvent and AuditAction are generated
-- from schema.prisma by Prisma Migrate. Use:
-- pnpm prisma migrate dev --name auth_foundation
