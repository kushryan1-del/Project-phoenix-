CREATE TYPE "ScheduleStatus" AS ENUM ('TENTATIVE', 'CONFIRMED', 'COMPLETED', 'CANCELLED');
ALTER TYPE "ScheduleType" ADD VALUE IF NOT EXISTS 'DAILY_WORK';
ALTER TABLE "ScheduleItem"
  ADD COLUMN "assignedToId" TEXT,
  ADD COLUMN "status" "ScheduleStatus" NOT NULL DEFAULT 'CONFIRMED',
  ADD COLUMN "allDay" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "ScheduleItem" ADD CONSTRAINT "ScheduleItem_assignedToId_fkey" FOREIGN KEY ("assignedToId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
CREATE INDEX "ScheduleItem_organizationId_startsAt_idx" ON "ScheduleItem"("organizationId", "startsAt");
CREATE INDEX "ScheduleItem_projectId_startsAt_idx" ON "ScheduleItem"("projectId", "startsAt");
CREATE INDEX "ScheduleItem_assignedToId_startsAt_idx" ON "ScheduleItem"("assignedToId", "startsAt");
