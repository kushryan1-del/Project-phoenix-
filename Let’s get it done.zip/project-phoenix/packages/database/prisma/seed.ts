import bcrypt from "bcryptjs";
import { PrismaClient, ProjectStatus, UserRole, LeadStage, TaskStatus, ScheduleType, ActivityType, EstimateStatus, DocumentStatus, InvoiceStatus, ChangeOrderStatus, LedgerType, LineItemType } from "@prisma/client";
const prisma=new PrismaClient();

async function main(){
 const org=await prisma.organization.create({data:{
   name:"Remarkable Home Improvement",registrationNumber:"PA151285",
   materialMarkupPercent:30,targetMarginPercent:30,materialTaxPercent:6,
   defaultLaborRate:100,warrantyMonths:12
 }});
 const passwordHash=await bcrypt.hash(process.env.SEED_OWNER_PASSWORD??"ChangeMeNow123!",12);
 const owner=await prisma.user.create({data:{organizationId:org.id,email:"owner@remarkablehomeimprovement.com",name:"Ryan",role:UserRole.OWNER,passwordHash}});
 const judy=await prisma.customer.create({data:{organizationId:org.id,name:"Judy Brown",city:"Jeannette",state:"PA"}});
 const megan=await prisma.customer.create({data:{organizationId:org.id,name:"Megan Weaver",city:"Trafford",state:"PA"}});
 await prisma.lead.create({data:{organizationId:org.id,customerId:megan.id,title:"Interior Door Replacement",source:"Referral",stage:LeadStage.PROPOSAL_SENT,estimatedValue:7900,probability:65}});
 const project=await prisma.project.create({data:{
   organizationId:org.id,customerId:judy.id,projectNumber:"RHI-2026-103",name:"Judy Brown Bathroom",
   projectType:"Bathroom Remodel",status:ProjectStatus.ACTIVE_PRODUCTION,progress:45,healthScore:88,
   scope:"Bathroom renovation including plumbing, electrical, drywall, tile, flooring, fixtures and finish work.",
   contractValue:9650,estimatedCost:6520,nextAction:"Complete tile and flooring."
 }});
 await prisma.projectTask.createMany({data:[
   {projectId:project.id,title:"Complete electrical rough-in",status:TaskStatus.DONE,priority:1},
   {projectId:project.id,title:"Install shower tile",status:TaskStatus.IN_PROGRESS,priority:1},
   {projectId:project.id,title:"Install flooring",status:TaskStatus.TODO,priority:1}
 ]});
 await prisma.scheduleItem.create({data:{organizationId:org.id,projectId:project.id,type:ScheduleType.MATERIAL_DELIVERY,title:"Tile and flooring materials",startsAt:new Date(Date.now()+86400000)}});

 const estimate=await prisma.estimate.create({data:{
   organizationId:org.id,customerId:judy.id,projectId:project.id,createdById:owner.id,estimateNumber:"EST-RHI-2026-103",projectName:"Judy Brown Bathroom",status:EstimateStatus.APPROVED,
   laborCost:4100,materialCost:2200,otherCost:220,materialMarkup:660,materialTax:171.60,
   contingency:250,totalCost:6520,sellingPrice:9650,grossProfit:2958.40,grossMargin:31.22,
   lineItems:{create:[
     {type:LineItemType.LABOR,description:"Bathroom remodeling labor",quantity:41,unit:"hour",unitCost:100,wastePercent:0,markupPercent:0,taxableMaterial:false,customerUnitPrice:140,cost:4100,total:5740,sortOrder:0},
     {type:LineItemType.MATERIAL,description:"Tile, flooring, drywall, electrical and plumbing materials",quantity:1,unit:"allowance",unitCost:2200,wastePercent:0,markupPercent:30,taxableMaterial:true,customerUnitPrice:2860,cost:2200,total:2860,sortOrder:1},
     {type:LineItemType.DISPOSAL,description:"Debris disposal",quantity:1,unit:"allowance",unitCost:220,wastePercent:0,markupPercent:0,taxableMaterial:false,customerUnitPrice:220,cost:220,total:220,sortOrder:2}
   ]}
 }});

 const proposal=await prisma.proposal.create({data:{
   projectId:project.id,estimateId:estimate.id,proposalNumber:"PROP-RHI-2026-103",status:DocumentStatus.SIGNED,
   title:"Bathroom Remodeling Proposal",contentJson:{premium:true,brand:"Remarkable Home Improvement"},
   subtotal:9478.40,materialTax:171.60,total:9650,signedAt:new Date()
 }});

 const contract=await prisma.contract.create({data:{
   projectId:project.id,proposalId:proposal.id,contractNumber:"CON-RHI-2026-103",
   status:DocumentStatus.SIGNED,contractValue:9650,depositPercent:40,midpointPercent:30,finalPercent:30,
   termsJson:{paymentSchedule:"40/30/30",warrantyMonths:12},signedAt:new Date()
 }});

 const inv1=await prisma.invoice.create({data:{
   projectId:project.id,invoiceNumber:"INV-RHI-2026-103-01",status:InvoiceStatus.PAID,
   description:"40% project deposit",subtotal:3860,materialTax:0,total:3860,amountPaid:3860,balanceDue:0
 }});
 await prisma.payment.create({data:{projectId:project.id,invoiceId:inv1.id,amount:3860,method:"Check",paidAt:new Date(),notes:"Deposit received."}});

 const inv2=await prisma.invoice.create({data:{
   projectId:project.id,invoiceNumber:"INV-RHI-2026-103-02",status:InvoiceStatus.SENT,
   description:"30% midpoint payment",subtotal:2895,materialTax:0,total:2895,amountPaid:0,balanceDue:2895
 }});

 const co=await prisma.changeOrder.create({data:{
   projectId:project.id,number:1,status:ChangeOrderStatus.APPROVED,title:"Additional electrical work",
   description:"Added circuit and required device changes.",addedCost:350,addedPrice:650,addedDays:1,materialTax:18
 }});

 await prisma.financialLedgerEntry.createMany({data:[
   {projectId:project.id,type:LedgerType.CONTRACT_VALUE,description:`Contract ${contract.contractNumber}`,amount:9650,sourceId:contract.id},
   {projectId:project.id,type:LedgerType.INVOICE,description:`Invoice ${inv1.invoiceNumber}`,amount:3860,sourceId:inv1.id},
   {projectId:project.id,type:LedgerType.PAYMENT,description:"Deposit payment received",amount:-3860},
   {projectId:project.id,type:LedgerType.INVOICE,description:`Invoice ${inv2.invoiceNumber}`,amount:2895,sourceId:inv2.id},
   {projectId:project.id,type:LedgerType.APPROVED_CHANGE_ORDER,description:"CO-1 Additional electrical work",amount:668,sourceId:co.id},
   {projectId:project.id,type:LedgerType.LABOR_COST,description:"Estimated project labor",amount:4100},
   {projectId:project.id,type:LedgerType.MATERIAL_COST,description:"Estimated project materials",amount:2200},
   {projectId:project.id,type:LedgerType.OTHER_COST,description:"Estimated disposal and other costs",amount:220}
 ]});
 await prisma.activity.createMany({data:[
   {projectId:project.id,actorId:owner.id,type:ActivityType.PROJECT_CREATED,summary:"Project created."},
   {projectId:project.id,actorId:owner.id,type:ActivityType.ESTIMATE_CREATED,summary:"Estimate approved at $9,650.00."},
   {projectId:project.id,actorId:owner.id,type:ActivityType.PROPOSAL_CREATED,summary:"Premium proposal signed."},
   {projectId:project.id,actorId:owner.id,type:ActivityType.CONTRACT_CREATED,summary:"Contract signed with 40/30/30 payment schedule."},
   {projectId:project.id,actorId:owner.id,type:ActivityType.PAYMENT,summary:"Deposit payment of $3,860.00 received."},
   {projectId:project.id,actorId:owner.id,type:ActivityType.CHANGE_ORDER,summary:"Change Order 1 approved for $668.00 including material tax."}
 ]});
 console.log("Sprint 5 seed complete.");
}
main().catch(e=>{console.error(e);process.exit(1)}).finally(()=>prisma.$disconnect());
