
import { z } from "zod";

export const estimateLineSchema = z.object({
  id: z.string().optional(),
  type: z.enum(["LABOR","MATERIAL","EQUIPMENT","SUBCONTRACTOR","DISPOSAL","PERMIT","OTHER"]),
  description: z.string().trim().min(1),
  quantity: z.coerce.number().min(0),
  unit: z.string().trim().min(1).default("each"),
  unitCost: z.coerce.number().min(0),
  markupPercent: z.coerce.number().min(0).default(30),
  wastePercent: z.coerce.number().min(0).max(100).default(0),
  taxable: z.coerce.boolean().default(false),
  optional: z.coerce.boolean().default(false),
  notes: z.string().optional().nullable()
});

export const estimateSchema = z.object({
  customerId: z.string().min(1),
  projectName: z.string().trim().min(2),
  projectType: z.string().trim().default("General"),
  projectAddress: z.string().optional().nullable(),
  taxRate: z.coerce.number().min(0).max(20).default(6),
  contingencyPercent: z.coerce.number().min(0).max(100).default(0),
  targetMarginPercent: z.coerce.number().min(0).max(95).default(30),
  internalNotes: z.string().optional().nullable(),
  customerNotes: z.string().optional().nullable(),
  lineItems: z.array(estimateLineSchema).min(1)
});

export type EstimateLine = z.infer<typeof estimateLineSchema>;
export type EstimateInput = z.infer<typeof estimateSchema>;

const money = (value:number) => Math.round((value + Number.EPSILON) * 100) / 100;

export function calculateEstimate(input: EstimateInput) {
  const rows = input.lineItems.map(line => {
    if (line.optional) return {...line, baseCost:0, wasteCost:0, cost:0, markup:0, sellingPrice:0, taxableAmount:0};
    const baseCost = line.quantity * line.unitCost;
    const wasteCost = line.type === "MATERIAL" ? baseCost * line.wastePercent / 100 : 0;
    const cost = baseCost + wasteCost;
    const markup = cost * line.markupPercent / 100;
    const sellingPrice = cost + markup;
    return {
      ...line,
      baseCost: money(baseCost),
      wasteCost: money(wasteCost),
      cost: money(cost),
      markup: money(markup),
      sellingPrice: money(sellingPrice),
      taxableAmount: line.type === "MATERIAL" && line.taxable ? money(sellingPrice) : 0
    };
  });

  const cost = rows.reduce((sum,row) => sum + row.cost, 0);
  const sellingSubtotal = rows.reduce((sum,row) => sum + row.sellingPrice, 0);
  const taxableMaterials = rows.reduce((sum,row) => sum + row.taxableAmount, 0);
  const contingency = cost * input.contingencyPercent / 100;
  const salesTax = taxableMaterials * input.taxRate / 100;
  const sellingPrice = sellingSubtotal + contingency + salesTax;
  const grossProfit = sellingPrice - salesTax - cost - contingency;
  const grossMargin = sellingPrice ? grossProfit / sellingPrice * 100 : 0;
  const targetPrice = (cost + contingency) / (1 - input.targetMarginPercent / 100);

  return {
    rows,
    totals: {
      cost: money(cost),
      sellingSubtotal: money(sellingSubtotal),
      taxableMaterials: money(taxableMaterials),
      contingency: money(contingency),
      salesTax: money(salesTax),
      sellingPrice: money(sellingPrice),
      grossProfit: money(grossProfit),
      grossMargin: money(grossMargin),
      targetPrice: money(targetPrice)
    },
    warnings: [
      ...(grossMargin < input.targetMarginPercent
        ? [`Gross margin is ${money(grossMargin)}%, below the ${input.targetMarginPercent}% target.`]
        : []),
      ...(rows.some(row => row.type === "MATERIAL" && !row.taxable && !row.optional)
        ? ["Review material lines marked non-taxable before sending."]
        : [])
    ]
  };
}
