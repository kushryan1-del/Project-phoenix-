export type PremiumDocumentBrand = {
  companyName: string;
  registrationNumber?: string;
  fullyInsured: boolean;
  primaryColor: string;
  secondaryColor: string;
  paymentSchedule: { deposit: number; midpoint: number; final: number };
  warrantyMonths: number;
  paymentMethods: string[];
};

export const remarkableHomeImprovementBrand: PremiumDocumentBrand = {
  companyName: "Remarkable Home Improvement",
  registrationNumber: "PA151285",
  fullyInsured: true,
  primaryColor: "#173a5e",
  secondaryColor: "#6b7280",
  paymentSchedule: { deposit: 40, midpoint: 30, final: 30 },
  warrantyMonths: 12,
  paymentMethods: ["Cash", "Check"]
};

export type ProposalLine = {
  type: string;
  description: string;
  quantity: number;
  unit: string;
  price: number;
};

export type PremiumDocumentModel = {
  title: string;
  documentNumber: string;
  customerName: string;
  customerEmail?: string;
  customerPhone?: string;
  projectName: string;
  projectAddress?: string;
  overview?: string;
  scopeItems: string[];
  lineItems?: ProposalLine[];
  exclusions?: string[];
  investment: number;
  materialTax?: number;
  total: number;
  terms: string[];
  notes?: string;
};

export function defaultProposalTerms() {
  return [
    "Payment schedule: 40% deposit, 30% progress payment, and 30% final payment.",
    "Materials and product availability are subject to supplier stock and manufacturer lead times.",
    "Changes to the approved scope require a written change order before additional work begins.",
    "Remarkable Home Improvement provides a one-year workmanship warranty unless a different written warranty is included.",
    "Customer-provided materials are not covered by the contractor's product warranty.",
    "Payments are accepted by cash or check."
  ];
}

export function buildProposalModel(input: PremiumDocumentModel) {
  return {
    brand: remarkableHomeImprovementBrand,
    documentType: "PROPOSAL" as const,
    generatedAt: new Date().toISOString(),
    ...input
  };
}

export function buildContractModel(input: PremiumDocumentModel) {
  return {
    brand: remarkableHomeImprovementBrand,
    documentType: "CONTRACT" as const,
    generatedAt: new Date().toISOString(),
    signatureBlocks: ["Customer", "Remarkable Home Improvement"],
    ...input
  };
}

export function buildInvoiceModel(input: PremiumDocumentModel) {
  return {
    brand: remarkableHomeImprovementBrand,
    documentType: "INVOICE" as const,
    generatedAt: new Date().toISOString(),
    acceptedPaymentMethods: remarkableHomeImprovementBrand.paymentMethods,
    ...input
  };
}
