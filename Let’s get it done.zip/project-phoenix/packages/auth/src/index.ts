import { z } from "zod";

export const roles = [
  "OWNER","OFFICE_MANAGER","ESTIMATOR","PROJECT_MANAGER","FIELD_EMPLOYEE","CUSTOMER"
] as const;

export type PhoenixRole = typeof roles[number];

export const permissions = {
  OWNER:["*"],
  OFFICE_MANAGER:[
    "customers:read","customers:write","leads:read","leads:write","projects:read",
    "projects:write","job_costing:read","job_costing:write","schedule:read","schedule:write","documents:read","documents:write",
    "invoices:read","payments:read"
  ],
  ESTIMATOR:[
    "customers:read","leads:read","projects:read","estimates:read","estimates:write",
    "materials:read","materials:write","proposals:read","proposals:write"
  ],
  PROJECT_MANAGER:[
    "customers:read","projects:read","projects:write","job_costing:read","job_costing:write","job_costing:read","job_costing:write","schedule:read","schedule:write",
    "tasks:read","tasks:write","job_sheets:read","job_sheets:write","files:read","files:write",
    "change_orders:read","change_orders:write"
  ],
  FIELD_EMPLOYEE:[
    "projects:read_assigned","tasks:read_assigned","tasks:update_assigned",
    "job_sheets:write_assigned","files:write_assigned","schedule:read_assigned"
  ],
  CUSTOMER:[
    "portal:read_own","proposals:read_own","contracts:read_own","invoices:read_own",
    "change_orders:read_own","files:read_shared"
  ]
} satisfies Record<PhoenixRole,string[]>;

export function hasPermission(role:PhoenixRole,permission:string){
  const allowed=permissions[role];
  return allowed.includes("*") || allowed.includes(permission);
}

export const loginSchema=z.object({
  email:z.string().email().transform(v=>v.trim().toLowerCase()),
  password:z.string().min(8).max(128),
  rememberMe:z.boolean().default(false)
});

export const forgotPasswordSchema=z.object({
  email:z.string().email().transform(v=>v.trim().toLowerCase())
});

export const resetPasswordSchema=z.object({
  token:z.string().min(32),
  password:z.string()
    .min(12)
    .max(128)
    .regex(/[A-Z]/,"Include an uppercase letter.")
    .regex(/[a-z]/,"Include a lowercase letter.")
    .regex(/[0-9]/,"Include a number.")
});
