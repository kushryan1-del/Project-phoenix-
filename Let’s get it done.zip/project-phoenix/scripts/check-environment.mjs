const required = ["DATABASE_URL", "AUTH_SECRET", "NEXTAUTH_URL"];
const missing = required.filter((name) => !process.env[name]?.trim());

if (missing.length) {
  console.error(`Missing required environment variables: ${missing.join(", ")}`);
  process.exit(1);
}

if ((process.env.AUTH_SECRET ?? "").length < 32) {
  console.error("AUTH_SECRET must be at least 32 characters.");
  process.exit(1);
}

console.log("Project Phoenix environment configuration is valid.");
