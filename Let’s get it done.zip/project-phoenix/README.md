# Project Phoenix — Release Candidate Milestone 2

This release adds Job Costing & Financial Control to the consolidated production repository.

## Major capabilities
- Actual labor-cost entry.
- Overtime and labor-burden calculations.
- Supplier purchases and project expenses.
- Receipt metadata foundation.
- Estimated-versus-actual cost comparison.
- Change-order impact.
- Invoice and collection summaries.
- Outstanding and unbilled revenue.
- Projected profit, margin and budget-health status.

## Run in Codespaces
1. Open the repository in GitHub Codespaces.
2. Copy `.env.example` to `.env`.
3. Configure `DATABASE_URL`, `AUTH_SECRET` and `SEED_OWNER_PASSWORD`.
4. Run `pnpm install`.
5. Run `pnpm db:generate`.
6. Run `pnpm prisma migrate dev --name job_costing`.
7. Run `pnpm db:seed`.
8. Run `pnpm typecheck`.
9. Run `pnpm build`.
10. Run `pnpm dev`.

## Important
This is a release-candidate development build. Do not post live financial or customer data until the Codespaces build, database migration, access-control tests, backups and staging review have passed.
