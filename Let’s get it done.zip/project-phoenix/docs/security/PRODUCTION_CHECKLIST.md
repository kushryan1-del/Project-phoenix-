# Authentication Production Checklist

- [ ] Strong AUTH_SECRET configured outside source control
- [ ] HTTPS enforced
- [ ] Secure proxy headers configured
- [ ] Rate limiting enabled
- [ ] CSRF defense applied to sensitive mutations
- [ ] Password reset email provider connected
- [ ] Audit log retention policy defined
- [ ] Session cleanup job scheduled
- [ ] Password reset token cleanup job scheduled
- [ ] Owner seed password replaced
- [ ] Role-permission tests passing
- [ ] Organization-isolation tests passing
- [ ] Database backups tested
- [ ] Incident-response owner assigned
