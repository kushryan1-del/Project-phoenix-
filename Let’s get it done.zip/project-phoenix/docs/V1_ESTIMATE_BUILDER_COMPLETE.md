
# Project Phoenix Version 1.0 — Estimate Builder Beta

## Delivered
- Customer and project estimate header.
- Editable labor, material, equipment, subcontractor, disposal, permit and other line items.
- Quantity, unit cost, waste percentage and markup controls.
- Material-only sales tax.
- Live estimated cost, selling price, gross profit and gross margin.
- Target-margin comparison and pricing warnings.
- Estimate list, new estimate and edit estimate screens.
- Save and update APIs.
- Organization and permission enforcement.
- Responsive field-friendly layout.

## Default pricing rules
- 30% line-item markup.
- 6% tax applied only to taxable material lines.
- 30% target gross margin.
- All values remain editable per estimate.

## Next milestone
- Searchable material and labor libraries.
- Reusable job assemblies.
- Autosave and revision history.
- Estimate duplication and project conversion.
- Premium proposal generation.
