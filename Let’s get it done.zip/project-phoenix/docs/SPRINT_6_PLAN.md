# Production Sprint 6 Plan

## Working forms and workflow
- Interactive estimate builder.
- Material library selector.
- Proposal preview and approval workflow.
- Contract signing preparation.
- Invoice creation and payment entry forms.
- Change-order approval workflow.
- Dashboard cash-flow alerts.

## Document rendering
- Branded PDF renderer.
- Matching DOCX renderer.
- Document version history.
- Stored generated files.
- Customer-download links.

## Production security
- Replace development session.
- Add audit logging for all financial writes.
- Add idempotency keys for payments.
- Add transaction-safe invoice/payment updates.
