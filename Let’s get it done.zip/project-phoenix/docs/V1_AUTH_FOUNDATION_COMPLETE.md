# Project Phoenix Version 1.0 — Authentication Foundation

## Delivered
- Database-backed user sessions.
- Secure, HTTP-only session cookies.
- Signed session JWTs linked to revocable server-side session records.
- Password hashing with bcrypt cost factor 12.
- Failed-login counting and temporary lockout.
- Account active/inactive state.
- Password reset token storage with hashing and expiration.
- Existing-session revocation after password reset.
- Logout and explicit session revocation.
- Role and permission matrix.
- Protected application routes and APIs.
- Organization-aware authenticated session.
- Authentication audit events.
- Login, forgot-password, reset-password and unauthorized screens.
- Production environment validation for the authentication secret.

## Security decisions
- Raw session and reset tokens are never stored in the database.
- Password reset responses do not reveal whether an account exists.
- Cookies are HTTP-only, same-site and secure in production.
- Authorization remains server-side; hiding a UI control is not considered security.
- Financial and document writes should add permission checks and audit events during the next hardening pass.

## Before deployment
1. Generate a strong `AUTH_SECRET`.
2. Configure a real email provider for password reset delivery.
3. Run the Prisma migration against a managed PostgreSQL staging database.
4. Change the seeded owner password immediately.
5. Add CSRF protection for sensitive mutation routes.
6. Add rate limiting at the edge or reverse proxy.
7. Configure HTTPS and secure proxy headers.
8. Test role boundaries for every API.
