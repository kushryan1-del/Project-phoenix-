# Project Phoenix Release Candidate — Milestone 2

## Job Costing & Financial Control

### Delivered
- Project labor-entry records.
- Regular and overtime labor costing.
- Optional labor-burden percentage.
- Supplier purchase records.
- Material, equipment, rental, permit, disposal, subcontractor and miscellaneous purchase categories.
- Project expense records.
- Receipt metadata foundation.
- Estimated-versus-actual cost comparison.
- Labor, material, other-cost and total variance calculations.
- Approved change-order revenue in the project forecast.
- Invoice, payment and outstanding-balance summary.
- Unbilled-revenue calculation.
- Projected gross profit and gross margin.
- On-budget, watch and over-budget health status.
- Organization-protected APIs and screens.
- Project activity entries for labor and purchases.
- Responsive project job-costing dashboard.

### Production hardening still required
- Run Prisma migration in Codespaces or staging.
- Type-check and production-build the repository.
- Add receipt object-storage uploads.
- Add edit/delete permissions and audit events.
- Add transaction-safe financial posting.
- Add accounting export rules.
- Add tests for every financial calculation.
