# Sprint 12 — Contracts and Electronic Customer Approval

Status: Complete in source code

## Delivered

- Contract dashboard and contract detail pages
- Matching contract generation from a proposal
- Print-ready branded contract
- Secure, single-use customer approval links
- 14-day approval-link expiration
- Revocation of older unused links whenever a new link is created
- Typed-name electronic acceptance with explicit consent
- Acceptance timestamp, email, IP address, and user-agent audit fields
- Automatic contract and proposal status updates
- Automatic project conversion to Scheduled after acceptance
- Automatic 40% deposit invoice creation after acceptance
- Project activity timeline entries for contract generation, link creation, acceptance, and invoice creation
- Organization-level access controls for internal contract pages
- Public customer contract review page that does not expose internal project data

## Production validation still required

1. Install dependencies in a network-enabled environment.
2. Run Prisma generation and the new migration.
3. Run TypeScript checking and production build.
4. Test email delivery for approval links before customer launch.
5. Obtain legal review of the standard contract language and electronic-signature process for Pennsylvania use.
6. Configure production HTTPS, database backups, error monitoring, and retention policies.
