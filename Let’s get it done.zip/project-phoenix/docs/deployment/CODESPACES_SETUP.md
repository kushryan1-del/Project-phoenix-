# Project Phoenix — Codespaces Setup

## 1. Create the Codespace

Open the private GitHub repository, select **Code → Codespaces → Create codespace on main**.
The included dev-container enables Corepack, installs pnpm dependencies, and forwards ports 3000 and 5432.

## 2. Start PostgreSQL

```bash
docker compose up -d postgres
```

## 3. Configure the environment

```bash
cp .env.example .env
```

Replace `AUTH_SECRET` with a secure value:

```bash
openssl rand -base64 48
```

Never commit `.env`.

## 4. Prepare the database

```bash
pnpm db:generate
pnpm db:migrate:deploy
pnpm db:seed
```

## 5. Validate and run

```bash
pnpm verify
pnpm dev
```

Open the forwarded port 3000 when Codespaces prompts you.
