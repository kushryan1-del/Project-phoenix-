# Environment Strategy

Project Phoenix uses three isolated environments.

## Development
Local computer or GitHub Codespaces. Uses a disposable PostgreSQL database and non-production credentials.

## Staging
Private deployment used for acceptance testing. It must have its own database, storage bucket, secrets, and test customer data.

## Production
Customer-facing environment. It must use unique production secrets, automated database backups, private storage, monitoring, and restricted administrator access.

Never share databases, storage buckets, secrets, or approval tokens between environments.
