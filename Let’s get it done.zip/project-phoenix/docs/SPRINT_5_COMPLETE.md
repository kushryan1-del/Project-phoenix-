# Production Sprint 5 — Complete

## Financial engine
- Estimate headers and detailed line items.
- Labor, material, equipment, subcontractor, disposal, permit and other cost categories.
- Material waste calculation.
- Material markup.
- Material-only sales tax.
- Contingency.
- Target margin support.
- Gross profit and margin calculations.

## Premium document engine
- Proposal data model.
- Contract data model.
- Invoice data model.
- Remarkable Home Improvement branding defaults.
- PA151285 registration.
- Fully insured language.
- 40/30/30 payment schedule.
- One-year workmanship warranty default.
- Cash and check payment methods.

## Project accounting
- Invoices.
- Partial and full payments.
- Outstanding balances.
- Change orders.
- Approved change-order revenue.
- Project financial ledger.
- Projected profit and margin.

## API coverage
- Estimates.
- Proposals.
- Contracts.
- Invoices.
- Payments.
- Change orders.
- Financial ledger.

## Remaining production work
- Real authentication provider.
- Actual PDF and DOCX renderers.
- Electronic signature provider.
- Online payment processor.
- Email/SMS delivery.
- Cloud database and object storage.
- Server-side permission enforcement on every action.
