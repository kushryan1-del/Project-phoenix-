# Project Phoenix V1 — Cloud & Mobile Foundation

## Implemented

- Installable Progressive Web App manifest and branded icons
- Service worker with application-shell caching and offline fallback
- IndexedDB mutation queue for offline field writes
- Automatic retry when connectivity returns
- Mobile-first Field App at `/field`
- Live sync status indicator
- Clock-in and clock-out capture
- Offline-capable Daily Job Sheet submission
- Today API for active projects, tasks, customers, and schedule items
- Mobile navigation entry and responsive field styling

## Field workflow

1. Open `/field` from a phone.
2. Install Phoenix to the home screen.
3. Review the active project and priority tasks.
4. Clock in, record completed work, materials, issues, notes, and cleanup.
5. Save while online or offline.
6. Phoenix synchronizes queued entries when connectivity returns.

## Production hardening still required

- Object storage and resumable photo uploads
- Push notification provider and permission controls
- Device registration and revocation
- Server-side idempotency table for offline mutation IDs
- Background sync support testing across iOS and Android
- Encryption and retention policy review
- Automated integration and end-to-end tests
