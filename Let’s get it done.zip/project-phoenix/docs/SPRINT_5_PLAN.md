# Production Sprint 5 Plan

## Financial and document engine
- Estimates with labor, materials, markup, margin, tax, and contingency.
- Premium proposal generator.
- Contract generator with 40/30/30 schedule.
- Invoice and payment tracking.
- Change orders.
- Matching PDF and Word output architecture.
- Project financial ledger.

## Field improvements
- Interactive task updates.
- Working Daily Job Sheet form.
- Photo uploader after object storage configuration.
- Crew time tracking.
- Customer daily approval signature.
