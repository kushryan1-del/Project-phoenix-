# Project Phoenix Version 1.0 Release Roadmap

## Milestone 1 — Secure authentication
Status: foundation complete.

## Milestone 2 — Premium document rendering
- Matching branded PDF and DOCX generation.
- File versioning and secure storage.
- Proposal, contract, invoice and change-order templates.

## Milestone 3 — Interactive estimate builder
- Working line-item editor.
- Material library.
- Live profit, margin, markup and tax calculations.
- Draft autosave and revision history.

## Milestone 4 — Mobile field operations
- Crew dashboard.
- Daily Job Sheets.
- Tasks, time, photos, signatures and material usage.

## Milestone 5 — Customer portal
- Proposal and contract access.
- Change-order approval.
- Invoices, project updates and shared files.

## Milestone 6 — Cloud release candidate
- Managed PostgreSQL.
- Object storage.
- Email delivery.
- Backups, monitoring, tests and staging deployment.
