"use client";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";

type Project={id:string;name:string;projectNumber:string;customer:{name:string}};
type Crew={id:string;name:string;role:string};
export default function ScheduleItemForm({projects,crew,defaultDate}:{projects:Project[];crew:Crew[];defaultDate:string}){
 const router=useRouter(); const [saving,setSaving]=useState(false); const [message,setMessage]=useState("");
 async function submit(e:FormEvent<HTMLFormElement>){e.preventDefault();setSaving(true);setMessage("");const form=new FormData(e.currentTarget);const body=Object.fromEntries(form.entries());
  const res=await fetch('/api/schedule',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)}); const data=await res.json(); setSaving(false);
  if(!res.ok){setMessage(data.error??'Unable to schedule item.');return;} e.currentTarget.reset();setMessage('Scheduled successfully.');router.refresh();}
 return <form className="schedule-form" onSubmit={submit}><h2>Add to schedule</h2><div className="form-grid">
  <label className="field field-wide"><span>Title</span><input name="title" required placeholder="Install vanity and toilet"/></label>
  <label className="field"><span>Type</span><select name="type" defaultValue="DAILY_WORK"><option value="DAILY_WORK">Daily work</option><option value="PROJECT_START">Project start</option><option value="SITE_VISIT">Site visit</option><option value="MATERIAL_DELIVERY">Material delivery</option><option value="INSPECTION">Inspection</option><option value="WALKTHROUGH">Walkthrough</option><option value="CREW_ASSIGNMENT">Crew assignment</option><option value="OTHER">Other</option></select></label>
  <label className="field"><span>Status</span><select name="status" defaultValue="CONFIRMED"><option value="CONFIRMED">Confirmed</option><option value="TENTATIVE">Tentative</option><option value="COMPLETED">Completed</option><option value="CANCELLED">Cancelled</option></select></label>
  <label className="field"><span>Start</span><input name="startsAt" type="datetime-local" defaultValue={`${defaultDate}T08:00`} required/></label>
  <label className="field"><span>End</span><input name="endsAt" type="datetime-local" defaultValue={`${defaultDate}T16:30`}/></label>
  <label className="field"><span>Project</span><select name="projectId" defaultValue=""><option value="">No project</option>{projects.map(p=><option key={p.id} value={p.id}>{p.projectNumber} — {p.name} ({p.customer.name})</option>)}</select></label>
  <label className="field"><span>Assigned crew</span><select name="assignedToId" defaultValue=""><option value="">Unassigned</option>{crew.map(u=><option key={u.id} value={u.id}>{u.name} — {u.role.replaceAll('_',' ')}</option>)}</select></label>
  <label className="field field-wide"><span>Location</span><input name="location" placeholder="Jobsite or supplier address"/></label>
  <label className="field field-wide"><span>Notes</span><textarea name="notes" rows={3} placeholder="Materials, access instructions, inspection notes…"/></label>
  <label className="schedule-check"><input type="checkbox" name="allDay" value="true"/> All-day item</label>
 </div><button className="btn" disabled={saving}>{saving?'Saving…':'Add schedule item'}</button>{message&&<p className="notice">{message}</p>}</form>
}
