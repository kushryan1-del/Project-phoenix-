"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
export default function ScheduleItemActions({id,status}:{id:string;status:string}){const router=useRouter();const [busy,setBusy]=useState(false);
 async function update(next:string){setBusy(true);await fetch(`/api/schedule/${id}`,{method:'PATCH',headers:{'content-type':'application/json'},body:JSON.stringify({status:next})});setBusy(false);router.refresh();}
 async function remove(){if(!confirm('Delete this schedule item?'))return;setBusy(true);await fetch(`/api/schedule/${id}`,{method:'DELETE'});setBusy(false);router.refresh();}
 return <div className="schedule-actions">{status!=="COMPLETED"&&<button disabled={busy} onClick={()=>update('COMPLETED')}>Complete</button>}{status!=="CANCELLED"&&<button disabled={busy} onClick={()=>update('CANCELLED')}>Cancel</button>}<button disabled={busy} onClick={remove}>Delete</button></div>}
