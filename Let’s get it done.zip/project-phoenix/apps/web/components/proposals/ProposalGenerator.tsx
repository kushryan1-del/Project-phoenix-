'use client';

import { useState } from "react";

export function ProposalGenerator({estimateId,defaultTitle}:{estimateId:string;defaultTitle:string}) {
  const [title,setTitle]=useState(defaultTitle);
  const [overview,setOverview]=useState("");
  const [notes,setNotes]=useState("");
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState("");

  async function generate() {
    setBusy(true); setError("");
    const response=await fetch("/api/proposals",{
      method:"POST",headers:{"content-type":"application/json"},
      body:JSON.stringify({estimateId,title,overview,notes})
    });
    const body=await response.json().catch(()=>({}));
    setBusy(false);
    if(!response.ok){setError(body.message??"Unable to generate proposal.");return;}
    location.href=`/proposals/${body.proposal.id}`;
  }

  return <section className="estimate-card proposal-generator">
    <div><h2>Generate premium proposal</h2><p className="muted">Turn this estimate into a branded, customer-ready proposal without retyping the scope or price.</p></div>
    <div className="form-grid">
      <label className="field field-wide"><span>Proposal title</span><input value={title} onChange={e=>setTitle(e.target.value)}/></label>
      <label className="field field-wide"><span>Project overview</span><textarea value={overview} onChange={e=>setOverview(e.target.value)} placeholder="Briefly explain the project and intended result."/></label>
      <label className="field field-wide"><span>Customer notes</span><textarea value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Optional scheduling, selections, or allowance notes."/></label>
    </div>
    {error&&<p className="form-error">{error}</p>}
    <button className="btn" disabled={busy||!title.trim()} onClick={generate}>{busy?"Generating…":"Generate proposal"}</button>
  </section>;
}
