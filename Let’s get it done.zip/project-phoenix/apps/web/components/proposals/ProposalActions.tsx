'use client';
import { useState } from "react";

export function ProposalActions({proposalId,status}:{proposalId:string;status:string}){
  const [busy,setBusy]=useState(false);
  async function update(next:string){
    setBusy(true);
    const response=await fetch(`/api/proposals/${proposalId}`,{method:"PATCH",headers:{"content-type":"application/json"},body:JSON.stringify({status:next})});
    setBusy(false);
    if(response.ok)location.reload();
  }
  return <div className="toolbar-actions">
    <a className="btn secondary" href={`/proposals/${proposalId}/print`} target="_blank">Print / Save PDF</a>
    {status==="DRAFT"&&<button className="btn" disabled={busy} onClick={()=>update("GENERATED")}>Finalize</button>}
    {["DRAFT","GENERATED"].includes(status)&&<button className="btn" disabled={busy} onClick={()=>update("SENT")}>Mark sent</button>}
    {status==="SENT"&&<button className="btn" disabled={busy} onClick={()=>update("SIGNED")}>Mark signed</button>}
  </div>;
}
