"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";

export function CustomerForm() {
  const router = useRouter();
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    setError("");
    const data = Object.fromEntries(new FormData(event.currentTarget));
    const response = await fetch("/api/customers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const payload = await response.json();
    if (!response.ok) {
      setError(payload.error ?? "Unable to create customer.");
      setSaving(false);
      return;
    }
    router.push(`/customers/${payload.id}`);
    router.refresh();
  }

  return <form className="card form-grid" onSubmit={submit}>
    <label className="field"><span>Customer name *</span><input name="name" required /></label>
    <label className="field"><span>Email</span><input name="email" type="email" /></label>
    <label className="field"><span>Phone</span><input name="phone" /></label>
    <label className="field field-wide"><span>Street address</span><input name="addressLine1" /></label>
    <label className="field"><span>City</span><input name="city" /></label>
    <label className="field"><span>State</span><input name="state" defaultValue="PA" /></label>
    <label className="field"><span>ZIP code</span><input name="postalCode" /></label>
    <label className="field field-wide"><span>Notes</span><textarea name="notes" rows={5} /></label>
    {error && <p className="form-error field-wide">{error}</p>}
    <div className="field-wide row"><button className="btn" disabled={saving}>{saving ? "Saving…" : "Create Customer"}</button></div>
  </form>;
}
