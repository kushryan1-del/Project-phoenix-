"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";

type CustomerOption = { id: string; name: string };

export function LeadForm({ customers }: { customers: CustomerOption[] }) {
  const router = useRouter();
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    setError("");
    const form = new FormData(event.currentTarget);
    const body = {
      customerId: form.get("customerId") || null,
      title: form.get("title"),
      source: form.get("source") || null,
      stage: form.get("stage"),
      estimatedValue: form.get("estimatedValue") || null,
      probability: Number(form.get("probability") || 25),
      followUpAt: form.get("followUpAt") || null,
      notes: form.get("notes") || null,
    };
    const response = await fetch("/api/leads", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const payload = await response.json();
    if (!response.ok) {
      setError(payload.error ?? "Unable to create lead.");
      setSaving(false);
      return;
    }
    router.push(`/leads/${payload.id}`);
    router.refresh();
  }

  return <form className="card form-grid" onSubmit={submit}>
    <label className="field field-wide"><span>Opportunity title *</span><input name="title" required placeholder="Example: Smith bathroom remodel" /></label>
    <label className="field"><span>Customer</span><select name="customerId"><option value="">Unassigned</option>{customers.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
    <label className="field"><span>Lead source</span><input name="source" placeholder="Referral, Google, Facebook…" /></label>
    <label className="field"><span>Stage</span><select name="stage" defaultValue="NEW"><option>NEW</option><option>CONTACTED</option><option>SITE_VISIT</option><option>ESTIMATING</option><option>PROPOSAL_SENT</option><option>WON</option><option>LOST</option></select></label>
    <label className="field"><span>Estimated value</span><input name="estimatedValue" type="number" min="0" step="0.01" /></label>
    <label className="field"><span>Probability %</span><input name="probability" type="number" min="0" max="100" defaultValue="25" /></label>
    <label className="field"><span>Follow-up date</span><input name="followUpAt" type="datetime-local" /></label>
    <label className="field field-wide"><span>Notes</span><textarea name="notes" rows={5} /></label>
    {error && <p className="form-error field-wide">{error}</p>}
    <div className="field-wide row"><button className="btn" disabled={saving}>{saving ? "Saving…" : "Create Lead"}</button></div>
  </form>;
}
