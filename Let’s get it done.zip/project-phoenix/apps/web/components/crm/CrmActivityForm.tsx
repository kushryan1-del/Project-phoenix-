"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";

export function CrmActivityForm({ customerId, leadId }: { customerId?: string; leadId?: string }) {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    setError("");
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/crm-activities", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ customerId, leadId, type: form.get("type"), summary: form.get("summary") }),
    });
    if (!response.ok) {
      const payload = await response.json();
      setError(payload.error ?? "Unable to save activity.");
      setSaving(false);
      return;
    }
    event.currentTarget.reset();
    setSaving(false);
    router.refresh();
  }

  return <form className="card" onSubmit={submit}>
    <h2>Log Contact</h2>
    <div className="form-grid">
      <label className="field"><span>Type</span><select name="type" defaultValue="NOTE"><option>CALL</option><option>EMAIL</option><option>TEXT</option><option>MEETING</option><option>SITE_VISIT</option><option>NOTE</option><option>FOLLOW_UP</option></select></label>
      <label className="field field-wide"><span>Summary *</span><textarea name="summary" rows={3} required /></label>
      {error && <p className="form-error field-wide">{error}</p>}
      <button className="btn" disabled={saving}>{saving ? "Saving…" : "Add Activity"}</button>
    </div>
  </form>;
}
