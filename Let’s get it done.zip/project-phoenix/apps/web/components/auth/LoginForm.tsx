'use client';
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";

export function LoginForm(){
  const router=useRouter();
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);
  async function submit(event:FormEvent<HTMLFormElement>){
    event.preventDefault(); setBusy(true); setMessage("");
    const data=new FormData(event.currentTarget);
    const response=await fetch("/api/auth/login",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({
      email:data.get("email"),password:data.get("password"),rememberMe:data.get("rememberMe")==="on"
    })});
    const body=await response.json();
    if(!response.ok){setMessage(body.message??"Unable to sign in.");setBusy(false);return;}
    router.push("/"); router.refresh();
  }
  return <form className="auth-form" onSubmit={submit}>
    <label>Email<input name="email" type="email" autoComplete="email" required /></label>
    <label>Password<input name="password" type="password" autoComplete="current-password" minLength={8} required /></label>
    <label className="checkbox"><input name="rememberMe" type="checkbox" /> Keep me signed in</label>
    {message&&<div className="auth-error">{message}</div>}
    <button className="btn" disabled={busy}>{busy?"Signing in…":"Sign in"}</button>
    <a href="/forgot-password">Forgot your password?</a>
  </form>;
}
