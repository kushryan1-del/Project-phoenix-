'use client';

import { FormEvent, useState } from "react";

export function PublicContractAcceptanceForm({token,customerName,customerEmail}:{token:string;customerName:string;customerEmail?:string|null}){
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState("");
  const [complete,setComplete]=useState(false);
  async function submit(event:FormEvent<HTMLFormElement>){
    event.preventDefault();setBusy(true);setError("");
    const data=new FormData(event.currentTarget);
    const response=await fetch(`/api/public/contracts/${token}/accept`,{
      method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({
        signedName:data.get("signedName"),email:data.get("email"),consent:data.get("consent")==="on"
      })
    });
    const body=await response.json().catch(()=>({}));
    setBusy(false);
    if(!response.ok){setError(body.message??"Unable to accept this contract.");return;}
    setComplete(true);
  }
  if(complete)return <section className="public-accept-card success-card"><h2>Contract accepted</h2><p>Thank you. Remarkable Home Improvement has received your signed acceptance. A copy can be saved or printed from this page.</p></section>;
  return <form className="public-accept-card" onSubmit={submit}>
    <h2>Electronic acceptance</h2>
    <p>Type your legal name and confirm that you agree to the contract terms. Your typed name will be recorded as your electronic signature.</p>
    <label className="field"><span>Legal name</span><input name="signedName" defaultValue={customerName} required/></label>
    <label className="field"><span>Email</span><input name="email" type="email" defaultValue={customerEmail??""} required/></label>
    <label className="accept-consent"><input name="consent" type="checkbox" required/> I have reviewed the contract, agree to its terms, and intend my typed name to serve as my electronic signature.</label>
    {error&&<p className="form-error">{error}</p>}
    <button className="btn public-sign-button" disabled={busy}>{busy?"Recording acceptance…":"Accept and sign contract"}</button>
  </form>;
}
