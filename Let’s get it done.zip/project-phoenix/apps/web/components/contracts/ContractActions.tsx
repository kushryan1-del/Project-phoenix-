'use client';

import { useState } from "react";

export function ContractActions({contractId,status}:{contractId:string;status:string}) {
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState("");

  async function update(next:string) {
    setBusy(true); setMessage("");
    const response=await fetch(`/api/contracts/${contractId}`,{
      method:"PATCH",headers:{"content-type":"application/json"},body:JSON.stringify({status:next})
    });
    setBusy(false);
    if(response.ok) location.reload();
    else setMessage("Unable to update contract.");
  }

  async function createApprovalLink() {
    setBusy(true); setMessage("");
    const response=await fetch(`/api/contracts/${contractId}/approval-link`,{method:"POST"});
    const body=await response.json().catch(()=>({}));
    setBusy(false);
    if(!response.ok){setMessage(body.message??"Unable to create approval link.");return;}
    await navigator.clipboard.writeText(body.url);
    setMessage("Secure approval link copied. It expires in 14 days.");
  }

  return <div>
    <div className="toolbar-actions">
      <a className="btn secondary" href={`/contracts/${contractId}/print`} target="_blank">Print / Save PDF</a>
      {status!=="SIGNED"&&status!=="VOID"&&<button className="btn" disabled={busy} onClick={createApprovalLink}>Copy approval link</button>}
      {status==="DRAFT"&&<button className="btn secondary" disabled={busy} onClick={()=>update("GENERATED")}>Finalize</button>}
      {status==="GENERATED"&&<button className="btn secondary" disabled={busy} onClick={()=>update("SENT")}>Mark sent</button>}
    </div>
    {message&&<p className="notice contract-action-message">{message}</p>}
  </div>;
}
