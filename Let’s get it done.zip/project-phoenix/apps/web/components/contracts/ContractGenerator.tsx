'use client';

import { useState } from "react";

export function ContractGenerator({projectId,proposalId,defaultNumber}:{projectId:string;proposalId:string;defaultNumber:string}){
  const [number,setNumber]=useState(defaultNumber);
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState("");
  async function generate(){
    setBusy(true);setError("");
    const response=await fetch(`/api/projects/${projectId}/contracts`,{
      method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({proposalId,contractNumber:number})
    });
    const body=await response.json().catch(()=>({}));
    setBusy(false);
    if(!response.ok){setError(body.message??"Unable to create contract.");return;}
    location.href=`/contracts/${body.id}`;
  }
  return <section className="data-card contract-generator">
    <h2>Create matching contract</h2>
    <p className="muted">Uses the approved proposal scope, total, payment schedule, warranty, and standard terms.</p>
    <label className="field"><span>Contract number</span><input value={number} onChange={e=>setNumber(e.target.value)}/></label>
    {error&&<p className="form-error">{error}</p>}
    <button className="btn" disabled={busy||!number.trim()} onClick={generate}>{busy?"Creating…":"Generate contract"}</button>
  </section>;
}
