"use client";
import { useEffect } from "react";
import { flushMutationQueue } from "@/lib/offline/queue";

export default function PwaBootstrap() {
  useEffect(() => {
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js");
    const sync = () => void flushMutationQueue();
    window.addEventListener("online", sync);
    navigator.serviceWorker?.addEventListener("message", event => {
      if (event.data?.type === "PHOENIX_SYNC") sync();
    });
    if (navigator.onLine) sync();
    return () => window.removeEventListener("online", sync);
  }, []);
  return null;
}
