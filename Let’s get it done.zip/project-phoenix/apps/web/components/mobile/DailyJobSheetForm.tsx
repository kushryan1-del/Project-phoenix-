"use client";
import { FormEvent, useState } from "react";
import { queueMutation, flushMutationQueue } from "@/lib/offline/queue";

export default function DailyJobSheetForm({projectId}:{projectId:string}) {
  const [message,setMessage]=useState("");
  const [clockedIn,setClockedIn]=useState(false);
  const [clockIn,setClockIn]=useState<string>();
  const [clockOut,setClockOut]=useState<string>();
  function now(){return new Date().toISOString();}
  async function submit(event:FormEvent<HTMLFormElement>) {
    event.preventDefault(); const form=new FormData(event.currentTarget);
    const payload={
      workDate:String(form.get("workDate")),
      workCompleted:String(form.get("workCompleted")),
      workPlanned:String(form.get("workPlanned")),
      materialsUsed:String(form.get("materialsUsed")),
      issues:String(form.get("issues")),
      weatherNotes:String(form.get("weatherNotes")),
      customerNotes:`Clock in: ${clockIn ?? "not recorded"}; Clock out: ${clockOut ?? "not recorded"}. ${String(form.get("customerNotes"))}`,
      crewJson:{clockIn,clockOut,cleanupComplete:form.get("cleanupComplete")==="on"}
    };
    const url=`/api/projects/${projectId}/job-sheets`;
    if(!navigator.onLine){await queueMutation({url,method:"POST",body:payload});setMessage("Saved offline. Phoenix will sync automatically.");return;}
    const response=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
    if(response.ok){setMessage("Daily Job Sheet saved."); event.currentTarget.reset();}
    else {await queueMutation({url,method:"POST",body:payload});setMessage("Connection problem. Saved safely for automatic sync.");}
    await flushMutationQueue();
  }
  return <form className="field-form" onSubmit={submit}>
    <div className="clock-row"><button type="button" className="btn" onClick={()=>{setClockedIn(true);setClockIn(now())}} disabled={clockedIn}>Clock In</button><button type="button" className="btn secondary" onClick={()=>{setClockedIn(false);setClockOut(now())}}>Clock Out</button></div>
    <label>Work date<input name="workDate" type="date" required defaultValue={new Date().toISOString().slice(0,10)}/></label>
    <label>Completed today<textarea name="workCompleted" required rows={4}/></label>
    <label>Next work planned<textarea name="workPlanned" rows={3}/></label>
    <label>Materials used<textarea name="materialsUsed" rows={3}/></label>
    <label>Weather / site conditions<textarea name="weatherNotes" rows={2}/></label>
    <label>Issues or delays<textarea name="issues" rows={2}/></label>
    <label>Customer notes<textarea name="customerNotes" rows={2}/></label>
    <label className="check"><input name="cleanupComplete" type="checkbox"/> Cleanup completed and site secured</label>
    <button className="btn field-submit" type="submit">Save Daily Job Sheet</button>
    {message && <p className="save-message">{message}</p>}
  </form>;
}
