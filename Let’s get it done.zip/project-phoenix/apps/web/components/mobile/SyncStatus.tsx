"use client";
import { useEffect, useState } from "react";
import { flushMutationQueue, pendingMutationCount } from "@/lib/offline/queue";

export default function SyncStatus() {
  const [online, setOnline] = useState(true);
  const [pending, setPending] = useState(0);
  async function refresh() { setOnline(navigator.onLine); setPending(await pendingMutationCount()); }
  useEffect(() => {
    refresh();
    const timer = window.setInterval(refresh, 3000);
    const handler = async () => { if (navigator.onLine) await flushMutationQueue(); await refresh(); };
    window.addEventListener("online", handler); window.addEventListener("offline", handler);
    return () => { clearInterval(timer); window.removeEventListener("online", handler); window.removeEventListener("offline", handler); };
  }, []);
  return <div className={`sync-pill ${online ? "online" : "offline"}`}>{online ? (pending ? `${pending} waiting to sync` : "Synced") : `Offline • ${pending} queued`}</div>;
}
