
'use client';
import { FormEvent,useState } from "react";

async function submitJson(url:string,form:HTMLFormElement) {
  const data=new FormData(form);
  const body=Object.fromEntries(data.entries());
  for(const key of ["regularHours","overtimeHours","hourlyCost","overtimeMultiplier","laborBurdenPercent","subtotal","salesTax","amount"]) {
    if(key in body) body[key]=Number(body[key]);
  }
  const response=await fetch(url,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(body)});
  const payload=await response.json();
  if(!response.ok) throw new Error(payload.message??"Unable to save.");
  form.reset();
  location.reload();
}

export function JobCostingForms({projectId}:{projectId:string}) {
  const [message,setMessage]=useState("");
  async function handle(event:FormEvent<HTMLFormElement>,endpoint:string) {
    event.preventDefault();setMessage("");
    try{await submitJson(`/api/job-costing/projects/${projectId}/${endpoint}`,event.currentTarget)}
    catch(error){setMessage(error instanceof Error?error.message:"Unable to save.")}
  }
  return <div className="job-cost-forms">
    {message&&<div className="auth-error">{message}</div>}
    <details className="job-cost-form" open>
      <summary>Record labor</summary>
      <form onSubmit={event=>handle(event,"labor")}>
        <div className="form-grid">
          <label>Worker<input name="workerName" required /></label>
          <label>Work date<input name="workDate" type="datetime-local" required /></label>
          <label>Task<input name="task" required /></label>
          <label>Regular hours<input name="regularHours" type="number" step="0.25" required /></label>
          <label>Overtime hours<input name="overtimeHours" type="number" step="0.25" defaultValue="0" /></label>
          <label>Hourly cost<input name="hourlyCost" type="number" step="0.01" defaultValue="100" required /></label>
          <label>OT multiplier<input name="overtimeMultiplier" type="number" step="0.1" defaultValue="1.5" /></label>
          <label>Labor burden %<input name="laborBurdenPercent" type="number" step="0.1" defaultValue="0" /></label>
        </div>
        <label>Notes<textarea name="notes" /></label>
        <button className="btn">Save labor</button>
      </form>
    </details>

    <details className="job-cost-form">
      <summary>Record purchase</summary>
      <form onSubmit={event=>handle(event,"purchases")}>
        <div className="form-grid">
          <label>Date<input name="purchasedAt" type="datetime-local" required /></label>
          <label>Supplier<input name="supplier" required /></label>
          <label>Description<input name="description" required /></label>
          <label>Category<select name="category">{["MATERIAL","EQUIPMENT","RENTAL","PERMIT","DISPOSAL","SUBCONTRACTOR","OTHER"].map(x=><option key={x}>{x}</option>)}</select></label>
          <label>Subtotal<input name="subtotal" type="number" step="0.01" required /></label>
          <label>Sales tax<input name="salesTax" type="number" step="0.01" defaultValue="0" /></label>
          <label>Receipt number<input name="receiptNumber" /></label>
          <label>Payment method<select name="paymentMethod">{["CASH","CHECK","CREDIT_CARD","DEBIT_CARD","ACCOUNT","OTHER"].map(x=><option key={x}>{x}</option>)}</select></label>
        </div>
        <label>Notes<textarea name="notes" /></label>
        <button className="btn">Save purchase</button>
      </form>
    </details>

    <details className="job-cost-form">
      <summary>Record other expense</summary>
      <form onSubmit={event=>handle(event,"expenses")}>
        <div className="form-grid">
          <label>Date<input name="occurredAt" type="datetime-local" required /></label>
          <label>Description<input name="description" required /></label>
          <label>Category<select name="category">{["EQUIPMENT","PERMIT","DISPOSAL","SUBCONTRACTOR","TRAVEL","DELIVERY","OTHER"].map(x=><option key={x}>{x}</option>)}</select></label>
          <label>Amount<input name="amount" type="number" step="0.01" required /></label>
        </div>
        <label>Notes<textarea name="notes" /></label>
        <button className="btn">Save expense</button>
      </form>
    </details>
  </div>;
}
