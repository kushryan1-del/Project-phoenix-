
'use client';

import { useMemo, useState } from "react";
import { calculateEstimate, type EstimateInput, type EstimateLine } from "@phoenix/estimating";

const currency = new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"});
const newLine: EstimateLine = {
  type:"MATERIAL", description:"", quantity:1, unit:"each", unitCost:0,
  markupPercent:30, wastePercent:0, taxable:true, optional:false, notes:""
};

export function EstimateBuilder({
  customers,
  estimateId,
  initial
}:{
  customers:Array<{id:string;name:string;address?:string|null}>,
  estimateId?:string,
  initial?:Partial<EstimateInput>
}) {
  const [form,setForm] = useState<EstimateInput>({
    customerId: initial?.customerId ?? customers[0]?.id ?? "",
    projectName: initial?.projectName ?? "",
    projectType: initial?.projectType ?? "General",
    projectAddress: initial?.projectAddress ?? "",
    taxRate: initial?.taxRate ?? 6,
    contingencyPercent: initial?.contingencyPercent ?? 0,
    targetMarginPercent: initial?.targetMarginPercent ?? 30,
    internalNotes: initial?.internalNotes ?? "",
    customerNotes: initial?.customerNotes ?? "",
    lineItems: initial?.lineItems?.length ? initial.lineItems : [{...newLine}]
  });
  const [message,setMessage] = useState("");
  const [saving,setSaving] = useState(false);
  const result = useMemo(() => calculateEstimate(form), [form]);

  function update<K extends keyof EstimateInput>(key:K,value:EstimateInput[K]) {
    setForm(current => ({...current,[key]:value}));
  }
  function updateLine(index:number,key:keyof EstimateLine,value:unknown) {
    update("lineItems",form.lineItems.map((line,i) => i===index ? {...line,[key]:value} : line));
  }
  async function save() {
    setSaving(true);
    setMessage("");
    const response = await fetch(estimateId ? `/api/estimates/${estimateId}` : "/api/estimates",{
      method: estimateId ? "PUT" : "POST",
      headers: {"content-type":"application/json"},
      body: JSON.stringify(form)
    });
    const body = await response.json();
    setSaving(false);
    if (!response.ok) {
      setMessage(body.message ?? "Unable to save estimate.");
      return;
    }
    setMessage(`Saved ${body.estimate.estimateNumber}.`);
    if (!estimateId) location.href = `/estimates/${body.estimate.id}`;
  }

  return <main className="estimate-builder">
    <header className="estimate-toolbar">
      <div>
        <h1>{estimateId ? "Edit Estimate" : "New Estimate"}</h1>
        <p>Remarkable Home Improvement estimating workspace</p>
      </div>
      <div className="toolbar-actions">
        <button className="btn secondary" onClick={() => update("lineItems",[...form.lineItems,{...newLine}])}>Add line</button>
        <button className="btn" disabled={saving} onClick={save}>{saving ? "Saving…" : "Save estimate"}</button>
      </div>
    </header>

    {message && <div className="notice">{message}</div>}

    <section className="estimate-card estimate-header-grid">
      <label>Customer<select value={form.customerId} onChange={e=>update("customerId",e.target.value)}>
        {customers.map(customer=><option value={customer.id} key={customer.id}>{customer.name}</option>)}
      </select></label>
      <label>Project name<input value={form.projectName} onChange={e=>update("projectName",e.target.value)} /></label>
      <label>Project type<input value={form.projectType} onChange={e=>update("projectType",e.target.value)} /></label>
      <label>Project address<input value={form.projectAddress ?? ""} onChange={e=>update("projectAddress",e.target.value)} /></label>
    </section>

    <section className="estimate-card table-scroll">
      <table className="estimate-table">
        <thead><tr><th>Type</th><th>Description</th><th>Qty</th><th>Unit</th><th>Unit cost</th><th>Waste %</th><th>Markup %</th><th>Tax</th><th>Selling</th><th></th></tr></thead>
        <tbody>{form.lineItems.map((line,index)=>{
          const calculated = result.rows[index];
          return <tr key={index}>
            <td><select value={line.type} onChange={e=>updateLine(index,"type",e.target.value)}>
              {["LABOR","MATERIAL","EQUIPMENT","SUBCONTRACTOR","DISPOSAL","PERMIT","OTHER"].map(type=><option key={type}>{type}</option>)}
            </select></td>
            <td><input value={line.description} onChange={e=>updateLine(index,"description",e.target.value)} /></td>
            <td><input type="number" step="0.01" value={line.quantity} onChange={e=>updateLine(index,"quantity",Number(e.target.value))} /></td>
            <td><input value={line.unit} onChange={e=>updateLine(index,"unit",e.target.value)} /></td>
            <td><input type="number" step="0.01" value={line.unitCost} onChange={e=>updateLine(index,"unitCost",Number(e.target.value))} /></td>
            <td><input type="number" step="0.1" value={line.wastePercent} onChange={e=>updateLine(index,"wastePercent",Number(e.target.value))} /></td>
            <td><input type="number" step="0.1" value={line.markupPercent} onChange={e=>updateLine(index,"markupPercent",Number(e.target.value))} /></td>
            <td><input type="checkbox" checked={line.taxable} disabled={line.type!=="MATERIAL"} onChange={e=>updateLine(index,"taxable",e.target.checked)} /></td>
            <td className="money">{currency.format(calculated.sellingPrice)}</td>
            <td><button className="icon-button" onClick={()=>update("lineItems",form.lineItems.filter((_,i)=>i!==index))}>×</button></td>
          </tr>;
        })}</tbody>
      </table>
    </section>

    <div className="estimate-bottom">
      <section className="estimate-card">
        <h2>Estimate settings</h2>
        <div className="settings-grid">
          <label>Material tax rate %<input type="number" step="0.1" value={form.taxRate} onChange={e=>update("taxRate",Number(e.target.value))} /></label>
          <label>Contingency %<input type="number" step="0.1" value={form.contingencyPercent} onChange={e=>update("contingencyPercent",Number(e.target.value))} /></label>
          <label>Target margin %<input type="number" step="0.1" value={form.targetMarginPercent} onChange={e=>update("targetMarginPercent",Number(e.target.value))} /></label>
        </div>
        <label>Internal notes<textarea value={form.internalNotes ?? ""} onChange={e=>update("internalNotes",e.target.value)} /></label>
        <label>Customer notes<textarea value={form.customerNotes ?? ""} onChange={e=>update("customerNotes",e.target.value)} /></label>
      </section>

      <aside className="estimate-card summary-card">
        <h2>Financial summary</h2>
        <dl>
          <div><dt>Estimated cost</dt><dd>{currency.format(result.totals.cost)}</dd></div>
          <div><dt>Selling subtotal</dt><dd>{currency.format(result.totals.sellingSubtotal)}</dd></div>
          <div><dt>Material-only tax</dt><dd>{currency.format(result.totals.salesTax)}</dd></div>
          <div><dt>Contingency</dt><dd>{currency.format(result.totals.contingency)}</dd></div>
          <div className="total"><dt>Selling price</dt><dd>{currency.format(result.totals.sellingPrice)}</dd></div>
          <div><dt>Gross profit</dt><dd>{currency.format(result.totals.grossProfit)}</dd></div>
          <div><dt>Gross margin</dt><dd>{result.totals.grossMargin.toFixed(1)}%</dd></div>
          <div><dt>Target-margin price</dt><dd>{currency.format(result.totals.targetPrice)}</dd></div>
        </dl>
        {result.warnings.length > 0 && <div className="warning-box">{result.warnings.map(warning=><p key={warning}>{warning}</p>)}</div>}
      </aside>
    </div>
  </main>;
}
