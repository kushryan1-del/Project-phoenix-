export default function Unauthorized(){
 return <main className="auth-shell"><section className="auth-card"><h1>Access restricted</h1><p>Your account does not have permission to open this area.</p><a className="btn" href="/">Return to dashboard</a></section></main>;
}
