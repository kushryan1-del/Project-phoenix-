import { notFound } from "next/navigation";
import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";
const usd=new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"});

export default async function ProjectWorkspace({params}:{params:Promise<{projectId:string}>}) {
  const session=await requireOrganization(); const {projectId}=await params;
  const project=await db.project.findFirst({
    where:{id:projectId,organizationId:session.organizationId},
    include:{
      customer:true,tasks:{orderBy:[{status:"asc"},{priority:"asc"}]},
      scheduleItems:{orderBy:{startsAt:"asc"}},jobSheets:{orderBy:{workDate:"desc"},take:5},
      photos:true,files:true,activities:{orderBy:{createdAt:"desc"},take:15,include:{actor:{select:{name:true}}},
      estimates:{orderBy:{createdAt:"desc"},take:3},
      proposals:{orderBy:{createdAt:"desc"},take:3},
      contracts:{orderBy:{createdAt:"desc"},take:3},
      invoices:{orderBy:{issueDate:"desc"},include:{payments:true}},
      changeOrders:{orderBy:{createdAt:"desc"}},
      ledgerEntries:{orderBy:{occurredAt:"desc"}}
    }
  });
  if(!project) notFound();

  const approvedCO=project.changeOrders.filter(c=>["APPROVED","COMPLETED"].includes(c.status)).reduce((s,c)=>s+Number(c.addedPrice)+Number(c.materialTax),0);
  const revenue=Number(project.contractValue)+approvedCO;
  const estimate=project.estimates[0];
  const estimatedCost=estimate?Number(estimate.totalCost):Number(project.estimatedCost);
  const collected=project.payments?.reduce?.((s:number,p:any)=>s+Number(p.amount),0) ?? project.invoices.reduce((s,i)=>s+Number(i.amountPaid),0);
  const outstanding=project.invoices.reduce((s,i)=>s+Number(i.balanceDue),0);
  const projectedProfit=revenue-estimatedCost;
  const margin=revenue>0?projectedProfit/revenue*100:0;

  return <>
    <header className="topbar"><div><h1>{project.name}</h1><p>{project.projectNumber} • {project.customer.name} • {project.status.replaceAll("_"," ")}</p></div><span className="badge">Health {project.healthScore}</span></header>
    <div className="tabs">{["Overview","Estimate","Proposal","Contract","Invoices","Payments","Change Orders","Ledger","Production"].map(t=><span className="tab" key={t}>{t}</span>)}</div>
    <section className="grid">
      <article className="card metric"><div className="label">Revenue With Approved COs</div><div className="value">{usd.format(revenue)}</div></article>
      <article className="card metric"><div className="label">Projected Profit</div><div className="value">{usd.format(projectedProfit)}</div></article>
      <article className="card metric"><div className="label">Projected Margin</div><div className="value">{margin.toFixed(1)}%</div></article>
      <article className="card metric"><div className="label">Outstanding Invoices</div><div className="value">{usd.format(outstanding)}</div></article>

      <article className="card half"><div className="row"><div><strong>Estimates</strong><div className="muted">Labor, materials, markup and margin</div></div><button className="btn">New Estimate</button></div>
        <div className="list">{project.estimates.map(e=><div className="item" key={e.id}><div className="row"><div><strong>{e.estimateNumber} v{e.version}</strong><div className="muted">{e.status} • Cost {usd.format(Number(e.totalCost))}</div></div><span className="badge">{usd.format(Number(e.sellingPrice))}</span></div><div className="muted" style={{marginTop:8}}>Profit {usd.format(Number(e.grossProfit))} • Margin {Number(e.grossMargin).toFixed(1)}%</div></div>)}</div>
      </article>

      <article className="card half"><div className="row"><div><strong>Documents</strong><div className="muted">Premium proposals and contracts</div></div><button className="btn secondary">Generate</button></div>
        <div className="list">{project.proposals.map(p=><div className="item" key={p.id}><a href={`/proposals/${p.id}`}><strong>Proposal {p.proposalNumber}</strong></a><div className="muted">{p.status} • {usd.format(Number(p.total))}</div></div>)}
        {project.contracts.map(c=><div className="item" key={c.id}><a href={`/contracts/${c.id}`}><strong>Contract {c.contractNumber}</strong></a><div className="muted">{c.status} • {usd.format(Number(c.contractValue))} • 40/30/30</div></div>)}</div>
      </article>

      <article className="card half"><div className="row"><div><strong>Invoices & Payments</strong><div className="muted">Collected {usd.format(collected)}</div></div><button className="btn">Create Invoice</button></div>
        <div className="list">{project.invoices.map(i=><div className="item" key={i.id}><div className="row"><div><strong>{i.invoiceNumber}</strong><div className="muted">{i.description} • {i.status.replaceAll("_"," ")}</div></div><span className="badge">{usd.format(Number(i.balanceDue))} due</span></div><div className="muted" style={{marginTop:8}}>Total {usd.format(Number(i.total))} • Paid {usd.format(Number(i.amountPaid))}</div></div>)}</div>
      </article>

      <article className="card half"><div className="row"><div><strong>Change Orders</strong><div className="muted">Approved revenue {usd.format(approvedCO)}</div></div><button className="btn secondary">New Change Order</button></div>
        <div className="list">{project.changeOrders.map(c=><div className="item" key={c.id}><div className="row"><div><strong>CO-{c.number}: {c.title}</strong><div className="muted">{c.status} • +{c.addedDays} days</div></div><span className="badge">{usd.format(Number(c.addedPrice)+Number(c.materialTax))}</span></div></div>)}</div>
      </article>

      <article className="card full"><strong>Project Financial Ledger</strong><table className="table"><thead><tr><th>Date</th><th>Type</th><th>Description</th><th>Amount</th></tr></thead><tbody>
        {project.ledgerEntries.map(e=><tr key={e.id}><td>{e.occurredAt.toLocaleDateString("en-US")}</td><td>{e.type.replaceAll("_"," ")}</td><td>{e.description}</td><td>{usd.format(Number(e.amount))}</td></tr>)}
      </tbody></table></article>
    </section>
  </>;
}
