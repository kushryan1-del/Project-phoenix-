import Link from "next/link";
import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";

const usd = new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",maximumFractionDigits:0});
export default async function Projects() {
  const session = await requireOrganization();
  const projects = await db.project.findMany({where:{organizationId:session.organizationId},include:{customer:true,_count:{select:{tasks:true,jobSheets:true,photos:true,files:true}}},orderBy:{updatedAt:"desc"}});
  return <>
    <header className="topbar"><div><h1>Projects</h1><p>Production workspaces, tasks, records and activity.</p></div><button className="btn">Create Project</button></header>
    <section className="card"><table className="table"><thead><tr><th>Project</th><th>Status</th><th>Progress</th><th>Value</th><th>Records</th></tr></thead><tbody>
      {projects.map(p=><tr key={p.id}><td><Link href={`/projects/${p.id}`}><strong>{p.name}</strong></Link><div className="muted">{p.projectNumber} • {p.customer.name}</div></td><td>{p.status.replaceAll("_"," ")}</td><td>{p.progress}%</td><td>{usd.format(Number(p.contractValue))}</td><td>{p._count.tasks} tasks • {p._count.jobSheets} sheets • {p._count.photos+p._count.files} files</td></tr>)}
    </tbody></table></section>
  </>;
}
