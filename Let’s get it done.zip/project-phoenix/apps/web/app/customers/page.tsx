import Link from "next/link";
import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";

export default async function Customers() {
  const session = await requireOrganization();
  const customers = await db.customer.findMany({where:{organizationId:session.organizationId},orderBy:{name:"asc"},include:{_count:{select:{projects:true,leads:true,crmActivities:true}}}});
  return <>
    <header className="topbar"><div><h1>Customers</h1><p>Customer records, opportunities, projects, and contact history.</p></div><Link className="btn" href="/customers/new">Add Customer</Link></header>
    <section className="card"><table className="table"><thead><tr><th>Name</th><th>Location</th><th>Phone</th><th>Projects</th><th>Leads</th><th>Contacts</th></tr></thead><tbody>
      {customers.map(c=><tr key={c.id}><td><Link href={`/customers/${c.id}`}><strong>{c.name}</strong></Link><div className="muted">{c.email ?? "No email"}</div></td><td>{[c.city,c.state].filter(Boolean).join(", ")||"—"}</td><td>{c.phone??"—"}</td><td>{c._count.projects}</td><td>{c._count.leads}</td><td>{c._count.crmActivities}</td></tr>)}
    </tbody></table>{customers.length===0&&<p className="empty-state">No customers yet. Add the first customer to begin the CRM.</p>}</section>
  </>;
}
