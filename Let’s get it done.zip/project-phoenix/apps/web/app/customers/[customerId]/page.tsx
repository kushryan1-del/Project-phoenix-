import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";
import { CrmActivityForm } from "@/components/crm/CrmActivityForm";

export default async function CustomerDetail({params}:{params:Promise<{customerId:string}>}) {
  const session=await requireOrganization(); const {customerId}=await params;
  const customer=await db.customer.findFirst({where:{id:customerId,organizationId:session.organizationId},include:{leads:{orderBy:{updatedAt:"desc"}},projects:{orderBy:{updatedAt:"desc"}},crmActivities:{orderBy:{createdAt:"desc"},include:{actor:{select:{name:true}}}}}});
  if(!customer) notFound();
  return <>
    <header className="topbar"><div><h1>{customer.name}</h1><p>{[customer.addressLine1,customer.city,customer.state,customer.postalCode].filter(Boolean).join(", ")||"No address recorded"}</p></div><Link className="btn-secondary" href="/leads/new">Create Lead</Link></header>
    <section className="grid"><article className="card" style={{gridColumn:"span 4"}}><h2>Contact</h2><p><strong>Phone</strong><br/>{customer.phone??"—"}</p><p><strong>Email</strong><br/>{customer.email??"—"}</p><p><strong>Notes</strong><br/>{customer.notes??"—"}</p></article><article className="card" style={{gridColumn:"span 8"}}><h2>Relationship Summary</h2><div className="metric-grid"><div className="metric"><span>Leads</span><strong>{customer.leads.length}</strong></div><div className="metric"><span>Projects</span><strong>{customer.projects.length}</strong></div><div className="metric"><span>Contacts</span><strong>{customer.crmActivities.length}</strong></div></div></article></section>
    <section className="grid"><article className="card" style={{gridColumn:"span 6"}}><h2>Opportunities</h2><div className="list">{customer.leads.map(l=><Link className="item" href={`/leads/${l.id}`} key={l.id}><strong>{l.title}</strong><div className="muted">{l.stage.replaceAll("_"," ")} • {l.probability}%</div></Link>)}{customer.leads.length===0&&<p className="muted">No leads yet.</p>}</div></article><article className="card" style={{gridColumn:"span 6"}}><h2>Projects</h2><div className="list">{customer.projects.map(p=><Link className="item" href={`/projects/${p.id}`} key={p.id}><strong>{p.projectNumber} — {p.name}</strong><div className="muted">{p.status.replaceAll("_"," ")} • {p.progress}% complete</div></Link>)}{customer.projects.length===0&&<p className="muted">No projects yet.</p>}</div></article></section>
    <CrmActivityForm customerId={customer.id}/><section className="card"><h2>Contact Timeline</h2><div className="timeline">{customer.crmActivities.map(a=><div className="timeline-item" key={a.id}><strong>{a.type.replaceAll("_"," ")}</strong><p>{a.summary}</p><span className="muted">{a.createdAt.toLocaleString()} • {a.actor?.name??"System"}</span></div>)}{customer.crmActivities.length===0&&<p className="muted">No contact activity recorded.</p>}</div></section>
  </>;
}
