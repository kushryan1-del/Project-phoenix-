import { CustomerForm } from "@/components/crm/CustomerForm";
import { requireOrganization } from "@/lib/guards";

export default async function NewCustomerPage() {
  await requireOrganization();
  return <>
    <header className="topbar"><div><h1>New Customer</h1><p>Create a customer record for estimates, proposals, and projects.</p></div></header>
    <CustomerForm />
  </>;
}
