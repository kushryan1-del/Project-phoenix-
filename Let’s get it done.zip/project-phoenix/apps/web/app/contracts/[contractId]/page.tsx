import { notFound } from "next/navigation";
import { db } from "@phoenix/database";
import { requirePermission } from "@/lib/auth/guards";
import { ContractActions } from "@/components/contracts/ContractActions";

type Terms={scopeItems?:string[];terms?:string[];overview?:string;projectAddress?:string;notes?:string};
const usd=new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"});
export default async function ContractPage({params}:{params:Promise<{contractId:string}>}){
  const session=await requirePermission("proposals:read");const {contractId}=await params;
  const contract=await db.contract.findFirst({where:{id:contractId,project:{organizationId:session.organizationId}},include:{project:{include:{customer:true}},proposal:true,approvalTokens:{orderBy:{createdAt:"desc"},take:1}}});
  if(!contract)notFound();const model=contract.termsJson as unknown as Terms;
  const deposit=Number(contract.contractValue)*Number(contract.depositPercent)/100;
  const midpoint=Number(contract.contractValue)*Number(contract.midpointPercent)/100;
  const final=Number(contract.contractValue)*Number(contract.finalPercent)/100;
  return <main className="page-shell"><header className="page-header"><div><p className="eyebrow">{contract.contractNumber}</p><h1>{contract.project.name}</h1><p>{contract.project.customer.name} · Matching construction contract</p></div><ContractActions contractId={contract.id} status={contract.status}/></header>
    <div className="proposal-layout"><section className="data-card"><h2>Project scope</h2><ol className="scope-list">{(model.scopeItems??[contract.project.scope??"Approved project scope."]).map((item,i)=><li key={i}>{item}</li>)}</ol><h2>Terms and conditions</h2><ol className="scope-list">{(model.terms??[]).map((item,i)=><li key={i}>{item}</li>)}</ol></section>
    <aside className="data-card proposal-summary"><span className="badge">{contract.status}</span><h2>Contract value</h2><p className="contract-value">{usd.format(Number(contract.contractValue))}</p><dl><div><dt>{Number(contract.depositPercent)}% deposit</dt><dd>{usd.format(deposit)}</dd></div><div><dt>{Number(contract.midpointPercent)}% progress</dt><dd>{usd.format(midpoint)}</dd></div><div><dt>{Number(contract.finalPercent)}% final</dt><dd>{usd.format(final)}</dd></div></dl>{contract.signedAt&&<div className="signed-panel"><strong>Accepted by {contract.customerSignedName??contract.customerSignature}</strong><span>{contract.signedAt.toLocaleString("en-US")}</span><span>{contract.customerSignedEmail}</span></div>}</aside></div>
  </main>;
}
