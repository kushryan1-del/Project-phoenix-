import { notFound } from "next/navigation";
import { db } from "@phoenix/database";
import { requirePermission } from "@/lib/auth/guards";

type Model={scopeItems?:string[];terms?:string[];overview?:string;projectAddress?:string;notes?:string};
const usd=new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"});
export default async function ContractPrint({params}:{params:Promise<{contractId:string}>}){
  const session=await requirePermission("proposals:read");const {contractId}=await params;
  const contract=await db.contract.findFirst({where:{id:contractId,project:{organizationId:session.organizationId}},include:{project:{include:{customer:true}}}});
  if(!contract)notFound();const model=contract.termsJson as unknown as Model;
  const customer=contract.project.customer;
  return <main className="proposal-print"><section className="print-cover"><div className="print-logo">RHI</div><p className="eyebrow">CONSTRUCTION CONTRACT</p><h1>{contract.project.name}</h1><div className="print-rule"/><h2>{customer.name}</h2><p>{contract.contractNumber}</p><footer>Remarkable Home Improvement<br/>PA151285 · Fully Insured<br/>One-Year Workmanship Warranty</footer></section>
    <section className="print-page"><h1>Agreement and project scope</h1><p>This agreement is between Remarkable Home Improvement and {customer.name} for the project described below.</p>{model.projectAddress&&<p><strong>Project address:</strong> {model.projectAddress}</p>}<ol>{(model.scopeItems??[contract.project.scope??"Approved project scope."]).map((item,i)=><li key={i}>{item}</li>)}</ol><h2>Contract investment</h2><table><tbody><tr className="grand"><th>Total contract value</th><td>{usd.format(Number(contract.contractValue))}</td></tr></tbody></table><div className="payment-grid"><div><strong>{Number(contract.depositPercent)}%</strong><span>{usd.format(Number(contract.contractValue)*Number(contract.depositPercent)/100)} deposit</span></div><div><strong>{Number(contract.midpointPercent)}%</strong><span>{usd.format(Number(contract.contractValue)*Number(contract.midpointPercent)/100)} progress</span></div><div><strong>{Number(contract.finalPercent)}%</strong><span>{usd.format(Number(contract.contractValue)*Number(contract.finalPercent)/100)} final</span></div></div></section>
    <section className="print-page"><h1>Terms and acceptance</h1><ol>{(model.terms??[]).map((term,i)=><li key={i}>{term}</li>)}</ol><div className="signatures"><div><span>{contract.customerSignedName??""}</span><small>Customer signature</small></div><div><span>{contract.signedAt?.toLocaleDateString("en-US")??""}</span><small>Date</small></div><div><span>{contract.contractorSignature??""}</span><small>Remarkable Home Improvement</small></div><div><span></span><small>Date</small></div></div>{contract.signedAt&&<p className="signature-audit">Electronically accepted by {contract.customerSignedName} ({contract.customerSignedEmail}) on {contract.signedAt.toLocaleString("en-US")}.</p>}</section>
  </main>;
}
