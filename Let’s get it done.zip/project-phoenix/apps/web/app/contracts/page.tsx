import Link from "next/link";
import { db } from "@phoenix/database";
import { requirePermission } from "@/lib/auth/guards";

const usd=new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"});
export default async function ContractsPage(){
  const session=await requirePermission("proposals:read");
  const contracts=await db.contract.findMany({where:{project:{organizationId:session.organizationId}},include:{project:{include:{customer:true}}},orderBy:{createdAt:"desc"}});
  const signed=contracts.filter(c=>c.status==="SIGNED").length;
  const pending=contracts.filter(c=>["GENERATED","SENT","VIEWED"].includes(c.status)).length;
  return <main className="page-shell"><header className="page-header"><div><p className="eyebrow">DOCUMENT CENTER</p><h1>Contracts</h1><p>Generate, send, track, and record customer acceptance.</p></div></header>
    <section className="metric-grid"><article className="metric"><span>Total contracts</span><strong>{contracts.length}</strong></article><article className="metric"><span>Awaiting acceptance</span><strong>{pending}</strong></article><article className="metric"><span>Signed</span><strong>{signed}</strong></article></section>
    <section className="data-card"><table className="data-table"><thead><tr><th>Contract</th><th>Customer</th><th>Project</th><th>Status</th><th className="money">Value</th></tr></thead><tbody>{contracts.map(c=><tr key={c.id}><td><Link href={`/contracts/${c.id}`}><strong>{c.contractNumber}</strong></Link></td><td>{c.project.customer.name}</td><td>{c.project.name}</td><td><span className="badge">{c.status}</span></td><td className="money">{usd.format(Number(c.contractValue))}</td></tr>)}</tbody></table>{contracts.length===0&&<p className="empty-state">Contracts generated from proposals will appear here.</p>}</section>
  </main>;
}
