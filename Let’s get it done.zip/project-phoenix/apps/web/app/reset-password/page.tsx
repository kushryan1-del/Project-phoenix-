'use client';
import { FormEvent,useState } from "react";
import { useSearchParams } from "next/navigation";
export default function ResetPassword(){
 const params=useSearchParams();const [message,setMessage]=useState("");
 async function submit(e:FormEvent<HTMLFormElement>){
  e.preventDefault();const data=new FormData(e.currentTarget);
  const response=await fetch("/api/auth/reset-password",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({token:params.get("token"),password:data.get("password")})});
  const body=await response.json();setMessage(response.ok?"Password changed. You may sign in.":body.message);
 }
 return <main className="auth-shell"><section className="auth-card"><h1>Choose a new password</h1><p>Use at least 12 characters with uppercase, lowercase and a number.</p>
 <form className="auth-form" onSubmit={submit}><label>New password<input name="password" type="password" minLength={12} required /></label><button className="btn">Change password</button></form>
 {message&&<div className="auth-success">{message}</div>}<a href="/login">Return to sign in</a></section></main>;
}
