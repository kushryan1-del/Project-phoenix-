import { notFound } from "next/navigation";
import { db } from "@phoenix/database";
import { hashToken } from "@/lib/auth/tokens";
import { PublicContractAcceptanceForm } from "@/components/contracts/PublicContractAcceptanceForm";

type Model={scopeItems?:string[];terms?:string[];projectAddress?:string};
const usd=new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"});
export default async function PublicContractPage({params}:{params:Promise<{token:string}>}){
  const {token}=await params;
  const record=await db.contractApprovalToken.findUnique({where:{tokenHash:hashToken(token)},include:{contract:{include:{project:{include:{customer:true}}}}}});
  if(!record)notFound();const expired=record.expiresAt<=new Date()||!!record.revokedAt;const used=!!record.usedAt||record.contract.status==="SIGNED";
  const contract=record.contract;const model=contract.termsJson as unknown as Model;const customer=contract.project.customer;
  return <main className="public-contract-shell"><header className="public-contract-header"><div className="print-logo">RHI</div><div><p className="eyebrow">SECURE CONTRACT REVIEW</p><h1>{contract.project.name}</h1><p>Remarkable Home Improvement · PA151285 · Fully Insured</p></div></header>
    <section className="public-contract-card"><div className="row"><div><strong>{contract.contractNumber}</strong><p>{customer.name}</p></div><span className="badge">{contract.status}</span></div><h2>Scope of work</h2><ol>{(model.scopeItems??[contract.project.scope??"Approved project scope."]).map((item,i)=><li key={i}>{item}</li>)}</ol><h2>Contract value</h2><p className="public-contract-total">{usd.format(Number(contract.contractValue))}</p><div className="payment-grid"><div><strong>{Number(contract.depositPercent)}%</strong><span>Deposit</span></div><div><strong>{Number(contract.midpointPercent)}%</strong><span>Progress</span></div><div><strong>{Number(contract.finalPercent)}%</strong><span>Final</span></div></div><h2>Terms and conditions</h2><ol>{(model.terms??[]).map((term,i)=><li key={i}>{term}</li>)}</ol></section>
    {expired?<section className="public-accept-card"><h2>Link expired</h2><p>Please contact Remarkable Home Improvement for a new secure approval link.</p></section>:used?<section className="public-accept-card success-card"><h2>Contract already accepted</h2><p>This contract was accepted on {contract.signedAt?.toLocaleString("en-US")} by {contract.customerSignedName??contract.customerSignature}.</p></section>:<PublicContractAcceptanceForm token={token} customerName={customer.name} customerEmail={customer.email}/>}<p className="public-security-note">This secure page records the acceptance time and basic request information for the contract audit trail.</p>
  </main>;
}
