import Link from "next/link";
import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";
import SyncStatus from "@/components/mobile/SyncStatus";
import DailyJobSheetForm from "@/components/mobile/DailyJobSheetForm";

export default async function FieldHome(){
  const session=await requireOrganization();
  const projects=await db.project.findMany({where:{organizationId:session.organizationId,status:{in:["SCHEDULED","ACTIVE_PRODUCTION"]}},include:{customer:true,tasks:{where:{status:{not:"DONE"}},orderBy:[{priority:"asc"},{dueAt:"asc"}],take:5}},orderBy:{updatedAt:"desc"},take:8});
  const primary=projects[0];
  return <div className="field-shell">
    <header className="field-header"><div><div className="eyebrow">PHOENIX FIELD</div><h1>Today’s Work</h1><p>{new Date().toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric"})}</p></div><SyncStatus/></header>
    {!primary?<section className="field-card"><h2>No active project</h2><p className="muted">Schedule or activate a project to begin field tracking.</p><Link className="btn" href="/projects">Open Projects</Link></section>:
    <>
      <section className="field-card hero-job"><div className="row"><div><span className="badge">{primary.status.replaceAll("_"," ")}</span><h2>{primary.name}</h2><p>{primary.customer.name}</p></div><div className="progress-ring">{primary.progress}%</div></div><p className="muted">{primary.nextAction || "Review today’s work and update the Daily Job Sheet."}</p><Link className="btn secondary" href={`/projects/${primary.id}`}>Full Project Workspace</Link></section>
      <section className="field-card"><h2>Today’s priorities</h2><div className="field-task-list">{primary.tasks.length?primary.tasks.map(t=><div className="field-task" key={t.id}><span>{t.priority===1?"High":t.priority===2?"Normal":"Low"}</span><strong>{t.title}</strong></div>):<p className="muted">No open tasks. Add tasks in the project workspace.</p>}</div></section>
      <section className="field-card"><h2>Daily Job Sheet</h2><p className="muted">Works online or offline. Unsynced entries stay securely on this device until service returns.</p><DailyJobSheetForm projectId={primary.id}/></section>
    </>}
    {projects.length>1&&<section className="field-card"><h2>Other active jobs</h2>{projects.slice(1).map(p=><Link className="other-job" key={p.id} href={`/projects/${p.id}`}><span>{p.projectNumber}</span><strong>{p.name}</strong><small>{p.progress}% complete</small></Link>)}</section>}
  </div>;
}
