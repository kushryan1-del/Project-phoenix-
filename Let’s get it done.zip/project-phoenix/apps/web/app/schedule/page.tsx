import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";
import ScheduleItemForm from "@/components/schedule/ScheduleItemForm";
import ScheduleItemActions from "@/components/schedule/ScheduleItemActions";

const dayFmt=new Intl.DateTimeFormat('en-US',{weekday:'short',month:'short',day:'numeric'});const timeFmt=new Intl.DateTimeFormat('en-US',{hour:'numeric',minute:'2-digit'});
function startOfWeek(d:Date){const x=new Date(d);const day=x.getDay();x.setDate(x.getDate()-day);x.setHours(0,0,0,0);return x}
export default async function SchedulePage(){const s=await requireOrganization();const now=new Date();const start=startOfWeek(now);const end=new Date(start);end.setDate(end.getDate()+14);
 const [items,projects,crew]=await Promise.all([
  db.scheduleItem.findMany({where:{organizationId:s.organizationId,startsAt:{gte:start,lt:end}},include:{project:{include:{customer:true}},assignedTo:true},orderBy:{startsAt:'asc'}}),
  db.project.findMany({where:{organizationId:s.organizationId,status:{in:['SCHEDULED','ACTIVE_PRODUCTION','CONTRACT']}},select:{id:true,name:true,projectNumber:true,customer:{select:{name:true}}},orderBy:{updatedAt:'desc'}}),
  db.user.findMany({where:{organizationId:s.organizationId,isActive:true,role:{in:['OWNER','PROJECT_MANAGER','FIELD_EMPLOYEE']}},select:{id:true,name:true,role:true},orderBy:{name:'asc'}})
 ]);
 const days=Array.from({length:14},(_,i)=>{const d=new Date(start);d.setDate(d.getDate()+i);return d});const active=items.filter(i=>i.status!=='CANCELLED').length;const inspections=items.filter(i=>i.type==='INSPECTION').length;const unassigned=items.filter(i=>!i.assignedToId&&i.status!=='CANCELLED').length;
 return <main className="page-shell"><header className="page-header"><div><p className="eyebrow">PRODUCTION CONTROL</p><h1>Scheduling & Calendar</h1><p>Coordinate project starts, daily work, crews, deliveries, inspections, and walkthroughs.</p></div></header>
 <section className="metric-grid"><article className="metric"><span>Next 14 days</span><strong>{active}</strong></article><article className="metric"><span>Inspections</span><strong>{inspections}</strong></article><article className="metric"><span>Needs crew assignment</span><strong>{unassigned}</strong></article></section>
 <section className="schedule-layout"><div className="schedule-calendar">{days.map(day=>{const list=items.filter(i=>i.startsAt.toDateString()===day.toDateString());const today=day.toDateString()===now.toDateString();return <article key={day.toISOString()} className={`schedule-day ${today?'today':''}`}><header><strong>{dayFmt.format(day)}</strong>{today&&<span>Today</span>}</header><div className="schedule-day-items">{list.map(item=><div key={item.id} className={`schedule-event status-${item.status.toLowerCase()}`}><div className="schedule-event-time">{item.allDay?'All day':timeFmt.format(item.startsAt)}{item.endsAt&&!item.allDay?`–${timeFmt.format(item.endsAt)}`:''}</div><strong>{item.title}</strong><small>{item.type.replaceAll('_',' ')} · {item.status}</small>{item.project&&<small>{item.project.projectNumber} · {item.project.customer.name}</small>}{item.assignedTo&&<small>Crew: {item.assignedTo.name}</small>}{item.location&&<small>{item.location}</small>}<ScheduleItemActions id={item.id} status={item.status}/></div>)}{list.length===0&&<p className="schedule-empty">No scheduled work</p>}</div></article>})}</div><aside className="data-card schedule-sidebar"><ScheduleItemForm projects={projects} crew={crew} defaultDate={now.toISOString().slice(0,10)}/></aside></section>
 </main>}
