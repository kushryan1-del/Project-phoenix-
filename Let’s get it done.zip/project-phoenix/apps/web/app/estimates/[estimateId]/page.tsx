import { notFound } from "next/navigation";
import { db } from "@phoenix/database";
import { requirePermission, assertOrganizationOwnership } from "@/lib/auth/guards";
import { EstimateBuilder } from "@/components/estimates/EstimateBuilder";
import { ProposalGenerator } from "@/components/proposals/ProposalGenerator";

export default async function EstimatePage({params}:{params:Promise<{estimateId:string}>}) {
  const session = await requirePermission("estimates:read");
  const {estimateId} = await params;
  const [estimate,customers] = await Promise.all([
    db.estimate.findUnique({where:{id:estimateId},include:{lineItems:{orderBy:{sortOrder:"asc"}},proposals:{orderBy:{createdAt:"desc"}}}}),
    db.customer.findMany({where:{organizationId:session.organizationId},select:{id:true,name:true,addressLine1:true,city:true,state:true,postalCode:true},orderBy:{name:"asc"}})
  ]);
  if (!estimate) notFound();
  assertOrganizationOwnership(estimate,session.organizationId);
  const customerOptions=customers.map(c=>({id:c.id,name:c.name,address:[c.addressLine1,c.city,c.state,c.postalCode].filter(Boolean).join(", ")}));

  return <>
    <EstimateBuilder
      customers={customerOptions}
      estimateId={estimate.id}
      initial={{
        customerId:estimate.customerId ?? "",
        projectName:estimate.projectName,
        taxRate:Number(estimate.taxRate),
        contingencyPercent:Number(estimate.contingencyPercent),
        targetMarginPercent:Number(estimate.targetMarginPercent),
        lineItems:estimate.lineItems.map(line=>({
          type:line.type,description:line.description,quantity:Number(line.quantity),unit:line.unit,
          unitCost:Number(line.unitCost)||Number(line.cost)/Math.max(Number(line.quantity),1),
          markupPercent:Number(line.markupPercent),wastePercent:Number(line.wastePercent),
          taxable:line.taxableMaterial,optional:false,notes:""
        }))
      }}
    />
    <div className="proposal-generator-wrap">
      <ProposalGenerator estimateId={estimate.id} defaultTitle={`${estimate.projectName} Proposal`}/>
      {estimate.proposals.length>0&&<section className="estimate-card"><h2>Generated proposals</h2><div className="list">{estimate.proposals.map(p=><a className="item row" key={p.id} href={`/proposals/${p.id}`}><strong>{p.proposalNumber}</strong><span>{p.status}</span></a>)}</div></section>}
    </div>
  </>;
}
