
import { db } from "@phoenix/database";
import { requirePermission } from "@/lib/auth/guards";

const currency = new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"});

export default async function EstimatesPage() {
  const session = await requirePermission("estimates:read");
  const estimates = await db.estimate.findMany({
    where:{organizationId:session.organizationId},
    include:{customer:true},
    orderBy:{updatedAt:"desc"}
  });

  return <main className="page-shell">
    <header className="page-header">
      <div><h1>Estimates</h1><p>Create and manage project pricing.</p></div>
      <a className="btn" href="/estimates/new">New estimate</a>
    </header>
    <section className="data-card">
      <table className="data-table">
        <thead><tr><th>Estimate</th><th>Customer</th><th>Project</th><th>Status</th><th>Price</th><th>Margin</th></tr></thead>
        <tbody>{estimates.map(estimate=><tr key={estimate.id}>
          <td><a href={`/estimates/${estimate.id}`}>{estimate.estimateNumber}</a></td>
          <td>{estimate.customer?.name ?? "Unassigned"}</td>
          <td>{estimate.projectName}</td>
          <td>{estimate.status}</td>
          <td>{currency.format(Number(estimate.sellingPrice))}</td>
          <td>{Number(estimate.grossMargin).toFixed(1)}%</td>
        </tr>)}</tbody>
      </table>
    </section>
  </main>;
}
