
import { db } from "@phoenix/database";
import { requirePermission } from "@/lib/auth/guards";
import { EstimateBuilder } from "@/components/estimates/EstimateBuilder";

export default async function NewEstimatePage() {
  const session = await requirePermission("estimates:write");
  const customers = await db.customer.findMany({
    where:{organizationId:session.organizationId},
    select:{id:true,name:true,address:true},
    orderBy:{name:"asc"}
  });
  return <EstimateBuilder customers={customers}/>;
}
