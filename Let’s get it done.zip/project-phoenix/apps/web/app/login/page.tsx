import { LoginForm } from "@/components/auth/LoginForm";
export default function LoginPage(){
  return <main className="auth-shell"><section className="auth-card">
    <div className="auth-brand">RHI</div>
    <h1>Project Phoenix</h1>
    <p>Secure access for Remarkable Home Improvement.</p>
    <LoginForm />
  </section></main>;
}
