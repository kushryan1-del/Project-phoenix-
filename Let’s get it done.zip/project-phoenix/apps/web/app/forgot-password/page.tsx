'use client';
import { FormEvent,useState } from "react";
export default function ForgotPassword(){
 const [message,setMessage]=useState("");
 async function submit(e:FormEvent<HTMLFormElement>){
  e.preventDefault();const data=new FormData(e.currentTarget);
  const response=await fetch("/api/auth/forgot-password",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({email:data.get("email")})});
  const body=await response.json();setMessage(body.message);
 }
 return <main className="auth-shell"><section className="auth-card"><h1>Reset password</h1><p>Enter your account email.</p>
 <form className="auth-form" onSubmit={submit}><label>Email<input name="email" type="email" required /></label><button className="btn">Send reset instructions</button></form>
 {message&&<div className="auth-success">{message}</div>}<a href="/login">Return to sign in</a></section></main>;
}
