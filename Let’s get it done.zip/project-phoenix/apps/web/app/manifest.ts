import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Project Phoenix Field",
    short_name: "Phoenix",
    description: "Remarkable Home Improvement field operations app",
    start_url: "/field",
    display: "standalone",
    background_color: "#f4f6f8",
    theme_color: "#17324d",
    orientation: "portrait-primary",
    icons: [
      { src: "/icons/phoenix-192.svg", sizes: "192x192", type: "image/svg+xml" },
      { src: "/icons/phoenix-512.svg", sizes: "512x512", type: "image/svg+xml" }
    ]
  };
}
