import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";
import { z } from "zod";

const schema = z.object({
  customerId: z.string().cuid().optional(),
  leadId: z.string().cuid().optional(),
  type: z.enum(["CALL","EMAIL","TEXT","MEETING","SITE_VISIT","NOTE","FOLLOW_UP"]),
  summary: z.string().trim().min(1).max(2000),
}).refine(value => value.customerId || value.leadId, "A customer or lead is required.");

export async function POST(request: Request) {
  const session = await requireOrganization();
  const parsed = schema.safeParse(await request.json());
  if (!parsed.success) return Response.json({ error: parsed.error.issues[0]?.message ?? "Invalid activity." }, { status: 400 });

  if (parsed.data.customerId) {
    const customer = await db.customer.findFirst({ where: { id: parsed.data.customerId, organizationId: session.organizationId } });
    if (!customer) return Response.json({ error: "Customer not found." }, { status: 404 });
  }
  if (parsed.data.leadId) {
    const lead = await db.lead.findFirst({ where: { id: parsed.data.leadId, organizationId: session.organizationId } });
    if (!lead) return Response.json({ error: "Lead not found." }, { status: 404 });
  }

  const activity = await db.crmActivity.create({ data: { ...parsed.data, organizationId: session.organizationId, actorId: session.userId } });
  return Response.json(activity, { status: 201 });
}
