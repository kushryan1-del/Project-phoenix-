import { db } from "@phoenix/database";
import { hashToken } from "@/lib/auth/tokens";
import { z } from "zod";

const schema=z.object({signedName:z.string().trim().min(2).max(120),email:z.string().email(),consent:z.literal(true)});

export async function POST(request:Request,{params}:{params:Promise<{token:string}>}){
  const {token}=await params;
  const parsed=schema.safeParse(await request.json());
  if(!parsed.success)return Response.json({message:"Enter your legal name, a valid email, and confirm your consent."},{status:400});
  const record=await db.contractApprovalToken.findUnique({where:{tokenHash:hashToken(token)},include:{contract:true}});
  if(!record||record.revokedAt||record.usedAt||record.expiresAt<=new Date())return Response.json({message:"This approval link is invalid or has expired."},{status:410});
  if(record.contract.status==="SIGNED")return Response.json({message:"This contract has already been signed."},{status:409});
  const forwarded=request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  const ip=forwarded??request.headers.get("x-real-ip")??undefined;
  const agent=request.headers.get("user-agent")??undefined;
  const now=new Date();
  await db.$transaction(async tx=>{
    await tx.contract.update({where:{id:record.contractId},data:{
      status:"SIGNED",signedAt:now,customerSignature:parsed.data.signedName,
      customerSignedName:parsed.data.signedName,customerSignedEmail:parsed.data.email,
      customerAcceptedIp:ip,customerAcceptedUserAgent:agent
    }});
    await tx.contractApprovalToken.update({where:{id:record.id},data:{usedAt:now}});
    await tx.proposal.updateMany({where:{id:record.contract.proposalId??"__none__"},data:{status:"SIGNED",signedAt:now,customerSignature:parsed.data.signedName}});
    await tx.project.update({where:{id:record.projectId},data:{status:"SCHEDULED",contractValue:record.contract.contractValue}});
    const deposit=Number(record.contract.contractValue)*Number(record.contract.depositPercent)/100;
    const invoiceCount=await tx.invoice.count({where:{projectId:record.projectId}});
    if(invoiceCount===0){
      const invoiceNumber=`${record.contract.contractNumber}-DEP`;
      await tx.invoice.create({data:{projectId:record.projectId,invoiceNumber,status:"DRAFT",description:`${Number(record.contract.depositPercent)}% contract deposit`,subtotal:deposit,total:deposit,balanceDue:deposit}});
      await tx.activity.create({data:{projectId:record.projectId,type:"INVOICE_CREATED",summary:`Deposit invoice ${invoiceNumber} created automatically.`}});
    }
    await tx.activity.create({data:{projectId:record.projectId,type:"DOCUMENT",summary:`Contract ${record.contract.contractNumber} electronically accepted by ${parsed.data.signedName}.`,metadata:{email:parsed.data.email,acceptedAt:now.toISOString()}}});
  });
  return Response.json({accepted:true});
}
