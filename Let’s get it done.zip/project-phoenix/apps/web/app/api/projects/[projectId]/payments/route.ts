import { db } from "@phoenix/database";
import { paymentCreateSchema } from "@phoenix/shared";
import { requireOrganization } from "@/lib/guards";

export async function POST(request:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session=await requireOrganization(); const {projectId}=await params;
  const project=await db.project.findFirst({where:{id:projectId,organizationId:session.organizationId}});
  if(!project) return new Response("Not found",{status:404});
  const parsed=paymentCreateSchema.safeParse(await request.json());
  if(!parsed.success) return Response.json({errors:parsed.error.flatten()},{status:400});
  const payment=await db.payment.create({data:{projectId,...parsed.data,paidAt:new Date(parsed.data.paidAt)}});
  if(parsed.data.invoiceId){
    const invoice=await db.invoice.findFirst({where:{id:parsed.data.invoiceId,projectId}});
    if(invoice){
      const amountPaid=Number(invoice.amountPaid)+parsed.data.amount;
      const balanceDue=Math.max(0,Number(invoice.total)-amountPaid);
      await db.invoice.update({where:{id:invoice.id},data:{
        amountPaid,balanceDue,status:balanceDue===0?"PAID":"PARTIALLY_PAID"
      }});
    }
  }
  await db.financialLedgerEntry.create({data:{projectId,type:"PAYMENT",description:`${payment.method} payment`,amount:-Number(payment.amount),sourceId:payment.id}});
  await db.activity.create({data:{projectId,actorId:session.id,type:"PAYMENT",summary:`Payment recorded: $${Number(payment.amount).toFixed(2)} by ${payment.method}.`}});
  return Response.json(payment,{status:201});
}
