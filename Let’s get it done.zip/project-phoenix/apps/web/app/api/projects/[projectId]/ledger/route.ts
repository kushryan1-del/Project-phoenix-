import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";

export async function GET(_:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session=await requireOrganization(); const {projectId}=await params;
  const project=await db.project.findFirst({where:{id:projectId,organizationId:session.organizationId}});
  if(!project) return new Response("Not found",{status:404});
  const entries=await db.financialLedgerEntry.findMany({where:{projectId},orderBy:{occurredAt:"desc"}});
  const balance=entries.reduce((sum,e)=>sum+Number(e.amount),0);
  return Response.json({entries,balance});
}
