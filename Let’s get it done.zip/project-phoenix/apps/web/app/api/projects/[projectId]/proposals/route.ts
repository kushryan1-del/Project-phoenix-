import { db } from "@phoenix/database";
import { buildProposalModel } from "@phoenix/documents";
import { requireOrganization } from "@/lib/guards";

export async function POST(request:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session=await requireOrganization(); const {projectId}=await params;
  const body=await request.json() as {estimateId:string;proposalNumber:string;title?:string;scopeItems?:string[]};
  const project=await db.project.findFirst({where:{id:projectId,organizationId:session.organizationId},include:{customer:true}});
  if(!project) return new Response("Not found",{status:404});
  const estimate=await db.estimate.findFirst({where:{id:body.estimateId,projectId}});
  if(!estimate) return new Response("Estimate not found",{status:404});
  const content=buildProposalModel({
    title:body.title??project.name,documentNumber:body.proposalNumber,
    customerName:project.customer.name,projectName:project.name,
    projectAddress:[project.customer.addressLine1,project.customer.city,project.customer.state,project.customer.postalCode].filter(Boolean).join(", "),
    scopeItems:body.scopeItems??[project.scope??"Scope to be finalized."],
    investment:Number(estimate.sellingPrice)-Number(estimate.materialTax),
    materialTax:Number(estimate.materialTax),total:Number(estimate.sellingPrice),
    terms:["40% deposit, 30% midpoint payment, and 30% final payment.","Materials are subject to availability.","One-year workmanship warranty unless otherwise stated."]
  });
  const proposal=await db.proposal.create({data:{
    projectId,estimateId:estimate.id,proposalNumber:body.proposalNumber,title:content.title,
    contentJson:content,subtotal:content.investment,materialTax:content.materialTax??0,total:content.total
  }});
  await db.activity.create({data:{projectId,actorId:session.id,type:"PROPOSAL_CREATED",summary:`Proposal ${proposal.proposalNumber} generated.`}});
  return Response.json(proposal,{status:201});
}
