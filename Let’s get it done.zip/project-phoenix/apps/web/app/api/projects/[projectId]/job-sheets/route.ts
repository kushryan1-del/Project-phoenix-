import { db } from "@phoenix/database";
import { jobSheetCreateSchema } from "@phoenix/shared";
import { requireOrganization } from "@/lib/guards";

export async function POST(request:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session = await requireOrganization();
  const {projectId} = await params;
  const project = await db.project.findFirst({where:{id:projectId,organizationId:session.organizationId}});
  if(!project) return new Response("Not found",{status:404});
  const parsed = jobSheetCreateSchema.safeParse(await request.json());
  if(!parsed.success) return Response.json({errors:parsed.error.flatten()},{status:400});
  const sheet = await db.dailyJobSheet.create({
    data:{projectId,preparedById:session.id,...parsed.data,workDate:new Date(parsed.data.workDate)}
  });
  await db.activity.create({data:{projectId,actorId:session.id,type:"JOB_SHEET_CREATED",summary:`Daily Job Sheet recorded for ${sheet.workDate.toLocaleDateString("en-US")}.`}});
  return Response.json(sheet,{status:201});
}
