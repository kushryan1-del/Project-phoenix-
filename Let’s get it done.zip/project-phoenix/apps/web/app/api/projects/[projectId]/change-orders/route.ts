import { db } from "@phoenix/database";
import { changeOrderCreateSchema } from "@phoenix/shared";
import { requireOrganization } from "@/lib/guards";

export async function POST(request:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session=await requireOrganization(); const {projectId}=await params;
  const project=await db.project.findFirst({where:{id:projectId,organizationId:session.organizationId}});
  if(!project) return new Response("Not found",{status:404});
  const parsed=changeOrderCreateSchema.safeParse(await request.json());
  if(!parsed.success) return Response.json({errors:parsed.error.flatten()},{status:400});
  const changeOrder=await db.changeOrder.create({data:{projectId,...parsed.data}});
  await db.activity.create({data:{projectId,actorId:session.id,type:"CHANGE_ORDER",summary:`Change Order ${changeOrder.number} created: ${changeOrder.title}.`}});
  return Response.json(changeOrder,{status:201});
}
