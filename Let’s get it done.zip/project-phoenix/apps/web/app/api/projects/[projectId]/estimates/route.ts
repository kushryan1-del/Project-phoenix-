import { db } from "@phoenix/database";
import { calculateEstimate, estimateCreateSchema } from "@phoenix/shared";
import { requireOrganization } from "@/lib/guards";

export async function GET(_:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session=await requireOrganization(); const {projectId}=await params;
  const project=await db.project.findFirst({where:{id:projectId,organizationId:session.organizationId}});
  if(!project) return new Response("Not found",{status:404});
  return Response.json(await db.estimate.findMany({where:{projectId},include:{lineItems:true},orderBy:{createdAt:"desc"}}));
}

export async function POST(request:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session=await requireOrganization(); const {projectId}=await params;
  const project=await db.project.findFirst({where:{id:projectId,organizationId:session.organizationId}});
  if(!project) return new Response("Not found",{status:404});
  const parsed=estimateCreateSchema.safeParse(await request.json());
  if(!parsed.success) return Response.json({errors:parsed.error.flatten()},{status:400});
  const totals=calculateEstimate(parsed.data);
  const estimate=await db.estimate.create({
    data:{
      organizationId:session.organizationId,projectId,customerId:project.customerId,createdById:session.id,estimateNumber:parsed.data.estimateNumber,projectName:project.name,
      version:parsed.data.version,notes:parsed.data.notes,
      laborCost:totals.laborCost,materialCost:totals.materialCost,otherCost:totals.otherCost,
      materialMarkup:totals.materialMarkup,materialTax:totals.materialTax,
      contingency:totals.contingency,totalCost:totals.totalCost,
      sellingPrice:totals.sellingPrice,grossProfit:totals.grossProfit,grossMargin:totals.marginPercent,
      taxRate:parsed.data.materialTaxPercent,contingencyPercent:parsed.data.contingencyPercent,targetMarginPercent:parsed.data.targetMarginPercent??30,
      lineItems:{create:totals.lines.map(line=>({type:line.type,description:line.description,quantity:line.quantity,unit:line.unit,unitCost:line.unitCost,wastePercent:line.wastePercent,markupPercent:line.markupPercent,taxableMaterial:line.taxableMaterial,customerUnitPrice:line.customerUnitPrice,cost:line.totalCost,total:line.totalPrice,sortOrder:line.sortOrder}))}
    },include:{lineItems:true}
  });
  await db.activity.create({data:{projectId,actorId:session.id,type:"ESTIMATE_CREATED",summary:`Estimate ${estimate.estimateNumber} created for $${Number(estimate.sellingPrice).toFixed(2)}.`}});
  return Response.json(estimate,{status:201});
}
