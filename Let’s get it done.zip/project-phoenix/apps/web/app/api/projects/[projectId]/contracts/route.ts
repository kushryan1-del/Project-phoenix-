import { db } from "@phoenix/database";
import { buildContractModel } from "@phoenix/documents";
import { requireOrganization } from "@/lib/guards";

export async function POST(request:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session=await requireOrganization(); const {projectId}=await params;
  const body=await request.json() as {proposalId?:string;contractNumber:string};
  const project=await db.project.findFirst({where:{id:projectId,organizationId:session.organizationId},include:{customer:true}});
  if(!project) return new Response("Not found",{status:404});
  const proposal=body.proposalId?await db.proposal.findFirst({where:{id:body.proposalId,projectId}}):null;
  const value=proposal?Number(proposal.total):Number(project.contractValue);
  const model=buildContractModel({
    title:project.name,documentNumber:body.contractNumber,customerName:project.customer.name,
    projectName:project.name,scopeItems:[project.scope??"Approved project scope."],
    investment:value,total:value,
    terms:["40% deposit due at signing.","30% midpoint payment due at the agreed production milestone.","30% final payment due at substantial completion.","Change orders must be approved in writing."]
  });
  const contract=await db.contract.create({data:{
    projectId,proposalId:proposal?.id,contractNumber:body.contractNumber,
    contractValue:value,termsJson:model
  }});
  await db.project.update({where:{id:projectId},data:{contractValue:value,status:"CONTRACT"}});
  await db.financialLedgerEntry.create({data:{projectId,type:"CONTRACT_VALUE",description:`Contract ${contract.contractNumber}`,amount:value,sourceId:contract.id}});
  await db.activity.create({data:{projectId,actorId:session.id,type:"CONTRACT_CREATED",summary:`Contract ${contract.contractNumber} created.`}});
  return Response.json(contract,{status:201});
}
