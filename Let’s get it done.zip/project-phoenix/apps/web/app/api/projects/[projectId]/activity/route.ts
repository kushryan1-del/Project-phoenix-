import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";

export async function GET(_:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session = await requireOrganization();
  const {projectId} = await params;
  const project = await db.project.findFirst({where:{id:projectId,organizationId:session.organizationId}});
  if(!project) return new Response("Not found",{status:404});
  const activity = await db.activity.findMany({where:{projectId},orderBy:{createdAt:"desc"},include:{actor:{select:{name:true}}}});
  return Response.json(activity);
}
