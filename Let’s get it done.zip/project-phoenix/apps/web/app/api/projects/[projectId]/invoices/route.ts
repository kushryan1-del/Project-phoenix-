import { db } from "@phoenix/database";
import { invoiceCreateSchema } from "@phoenix/shared";
import { requireOrganization } from "@/lib/guards";

export async function GET(_:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session=await requireOrganization(); const {projectId}=await params;
  const project=await db.project.findFirst({where:{id:projectId,organizationId:session.organizationId}});
  if(!project) return new Response("Not found",{status:404});
  return Response.json(await db.invoice.findMany({where:{projectId},include:{payments:true},orderBy:{issueDate:"desc"}}));
}

export async function POST(request:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session=await requireOrganization(); const {projectId}=await params;
  const project=await db.project.findFirst({where:{id:projectId,organizationId:session.organizationId}});
  if(!project) return new Response("Not found",{status:404});
  const parsed=invoiceCreateSchema.safeParse(await request.json());
  if(!parsed.success) return Response.json({errors:parsed.error.flatten()},{status:400});
  const total=parsed.data.subtotal+parsed.data.materialTax;
  const invoice=await db.invoice.create({data:{
    projectId,...parsed.data,dueDate:parsed.data.dueDate?new Date(parsed.data.dueDate):undefined,
    total,balanceDue:total
  }});
  await db.financialLedgerEntry.create({data:{projectId,type:"INVOICE",description:`Invoice ${invoice.invoiceNumber}`,amount:invoice.total,sourceId:invoice.id}});
  await db.activity.create({data:{projectId,actorId:session.id,type:"INVOICE_CREATED",summary:`Invoice ${invoice.invoiceNumber} created for $${Number(invoice.total).toFixed(2)}.`}});
  return Response.json(invoice,{status:201});
}
