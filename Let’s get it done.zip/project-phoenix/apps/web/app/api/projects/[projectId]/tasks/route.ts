import { db } from "@phoenix/database";
import { taskCreateSchema } from "@phoenix/shared";
import { requireOrganization } from "@/lib/guards";

export async function GET(_:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session = await requireOrganization();
  const {projectId} = await params;
  const project = await db.project.findFirst({where:{id:projectId,organizationId:session.organizationId}});
  if(!project) return new Response("Not found",{status:404});
  return Response.json(await db.projectTask.findMany({where:{projectId},orderBy:[{status:"asc"},{priority:"asc"},{createdAt:"desc"}]}));
}

export async function POST(request:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session = await requireOrganization();
  const {projectId} = await params;
  const project = await db.project.findFirst({where:{id:projectId,organizationId:session.organizationId}});
  if(!project) return new Response("Not found",{status:404});
  const parsed = taskCreateSchema.safeParse(await request.json());
  if(!parsed.success) return Response.json({errors:parsed.error.flatten()},{status:400});
  const task = await db.projectTask.create({data:{projectId,...parsed.data,dueAt:parsed.data.dueAt?new Date(parsed.data.dueAt):undefined}});
  await db.activity.create({data:{projectId,actorId:session.id,type:"TASK_CREATED",summary:`Task created: ${task.title}`}});
  return Response.json(task,{status:201});
}
