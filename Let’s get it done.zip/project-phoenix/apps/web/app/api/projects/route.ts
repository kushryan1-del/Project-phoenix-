import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";

export async function GET() {
  const session = await requireOrganization();
  const projects = await db.project.findMany({
    where:{organizationId:session.organizationId},
    orderBy:{updatedAt:"desc"},
    include:{customer:true,_count:{select:{tasks:true,jobSheets:true,photos:true,files:true}}}
  });
  return Response.json(projects);
}
