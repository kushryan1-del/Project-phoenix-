
import { db } from "@phoenix/database";
import { requirePermission, assertOrganizationOwnership } from "@/lib/auth/guards";
import { parseAndCalculateEstimate } from "@/lib/estimates/save";

export async function GET(_:Request,{params}:{params:Promise<{estimateId:string}>}) {
  const session = await requirePermission("estimates:read");
  const {estimateId} = await params;
  const estimate = await db.estimate.findUnique({where:{id:estimateId},include:{customer:true,lineItems:true}});
  assertOrganizationOwnership(estimate,session.organizationId);
  return Response.json({estimate});
}

export async function PUT(request:Request,{params}:{params:Promise<{estimateId:string}>}) {
  const session = await requirePermission("estimates:write");
  const {estimateId} = await params;
  const current = await db.estimate.findUnique({where:{id:estimateId}});
  assertOrganizationOwnership(current,session.organizationId);
  const {estimate,calculation} = parseAndCalculateEstimate(await request.json());

  const updated = await db.$transaction(async tx => {
    await tx.estimateLineItem.deleteMany({where:{estimateId}});
    return tx.estimate.update({
      where:{id:estimateId},
      data:{
        customerId:estimate.customerId,
        projectName:estimate.projectName,
        materialCost:calculation.rows.filter(r=>r.type==="MATERIAL").reduce((sum,r)=>sum+r.cost,0),
        laborCost:calculation.rows.filter(r=>r.type==="LABOR").reduce((sum,r)=>sum+r.cost,0),
        sellingPrice:calculation.totals.sellingPrice,
        grossProfit:calculation.totals.grossProfit,
        grossMargin:calculation.totals.grossMargin,
        materialTax:calculation.totals.salesTax,
        contingency:calculation.totals.contingency,
        totalCost:calculation.totals.cost,
        taxRate:estimate.taxRate,
        contingencyPercent:estimate.contingencyPercent,
        targetMarginPercent:estimate.targetMarginPercent,
        lineItems:{create:calculation.rows.map((line,index)=>({
          type:line.type,description:line.description,quantity:line.quantity,
          unit:estimate.lineItems[index].unit,unitCost:estimate.lineItems[index].unitCost,
          wastePercent:estimate.lineItems[index].wastePercent,markupPercent:estimate.lineItems[index].markupPercent,
          taxableMaterial:estimate.lineItems[index].taxable,customerUnitPrice:line.quantity?line.sellingPrice/line.quantity:line.sellingPrice,
          cost:line.cost,total:line.sellingPrice,sortOrder:index
        }))}
      },
      include:{customer:true,lineItems:true}
    });
  });
  return Response.json({estimate:updated,calculation});
}
