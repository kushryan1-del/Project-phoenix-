
import { db } from "@phoenix/database";
import { requirePermission } from "@/lib/auth/guards";
import { parseAndCalculateEstimate } from "@/lib/estimates/save";

export async function GET() {
  const session = await requirePermission("estimates:read");
  const estimates = await db.estimate.findMany({
    where:{organizationId:session.organizationId},
    include:{customer:true,lineItems:true},
    orderBy:{updatedAt:"desc"}
  });
  return Response.json({estimates});
}

export async function POST(request:Request) {
  const session = await requirePermission("estimates:write");
  const {estimate,calculation} = parseAndCalculateEstimate(await request.json());
  const count = await db.estimate.count({where:{organizationId:session.organizationId}});
  const estimateNumber = `EST-${new Date().getFullYear()}-${String(count+1).padStart(4,"0")}`;

  const created = await db.estimate.create({
    data:{
      organizationId:session.organizationId,
      customerId:estimate.customerId,
      projectName:estimate.projectName,
      estimateNumber,
      status:"DRAFT",
      createdById:session.id,
      materialCost:calculation.rows.filter(r=>r.type==="MATERIAL").reduce((sum,r)=>sum+r.cost,0),
      laborCost:calculation.rows.filter(r=>r.type==="LABOR").reduce((sum,r)=>sum+r.cost,0),
      sellingPrice:calculation.totals.sellingPrice,
      grossProfit:calculation.totals.grossProfit,
      grossMargin:calculation.totals.grossMargin,
      materialTax:calculation.totals.salesTax,
      contingency:calculation.totals.contingency,
      totalCost:calculation.totals.cost,
      taxRate:estimate.taxRate,
      contingencyPercent:estimate.contingencyPercent,
      targetMarginPercent:estimate.targetMarginPercent,
      lineItems:{create:calculation.rows.map((line,index)=>({
        type:line.type,
        description:line.description,
        quantity:line.quantity,
        unit:estimate.lineItems[index].unit,
        unitCost:estimate.lineItems[index].unitCost,
        wastePercent:estimate.lineItems[index].wastePercent,
        markupPercent:estimate.lineItems[index].markupPercent,
        taxableMaterial:estimate.lineItems[index].taxable,
        customerUnitPrice:line.quantity ? line.sellingPrice/line.quantity : line.sellingPrice,
        cost:line.cost,
        total:line.sellingPrice,
        sortOrder:index
      }))}
    },
    include:{customer:true,lineItems:true}
  });
  return Response.json({estimate:created,calculation},{status:201});
}
