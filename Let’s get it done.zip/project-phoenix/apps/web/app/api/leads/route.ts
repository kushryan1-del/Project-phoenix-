import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";
import { z } from "zod";

const leadSchema = z.object({
  customerId: z.string().cuid().nullable().optional(),
  title: z.string().trim().min(1).max(250),
  source: z.string().trim().max(100).nullable().optional(),
  stage: z.enum(["NEW","CONTACTED","SITE_VISIT","ESTIMATING","PROPOSAL_SENT","WON","LOST"]).default("NEW"),
  estimatedValue: z.coerce.number().min(0).nullable().optional(),
  probability: z.coerce.number().int().min(0).max(100).default(25),
  followUpAt: z.string().nullable().optional(),
  notes: z.string().trim().max(5000).nullable().optional(),
});

export async function GET() {
  const session = await requireOrganization();
  return Response.json(await db.lead.findMany({where:{organizationId:session.organizationId},orderBy:{updatedAt:"desc"},include:{customer:true}}));
}

export async function POST(request: Request) {
  const session = await requireOrganization();
  const parsed = leadSchema.safeParse(await request.json());
  if (!parsed.success) return Response.json({error:parsed.error.issues[0]?.message ?? "Invalid lead."},{status:400});
  if (parsed.data.customerId) {
    const customer = await db.customer.findFirst({where:{id:parsed.data.customerId,organizationId:session.organizationId}});
    if (!customer) return Response.json({error:"Customer not found."},{status:404});
  }
  const lead = await db.lead.create({data:{...parsed.data,organizationId:session.organizationId,followUpAt:parsed.data.followUpAt?new Date(parsed.data.followUpAt):null}});
  return Response.json(lead,{status:201});
}
