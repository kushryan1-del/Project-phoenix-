import { requireOrganization } from "@/lib/guards";

export async function POST(request:Request) {
  const session = await requireOrganization();
  const body = await request.json() as {projectId?:string;fileName?:string;contentType?:string};
  if(!body.projectId || !body.fileName) return new Response("projectId and fileName are required",{status:400});

  // Production implementation should issue a short-lived signed URL from S3/R2/Blob.
  const storageKey = `${session.organizationId}/${body.projectId}/${crypto.randomUUID()}-${body.fileName}`;
  return Response.json({
    storageKey,
    uploadUrl:null,
    status:"storage-provider-not-configured",
    message:"Configure object storage before accepting live uploads."
  });
}
