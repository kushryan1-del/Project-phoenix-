import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";
import { z } from "zod";

const customerSchema = z.object({
  name: z.string().trim().min(1).max(200),
  email: z.string().trim().email().optional().or(z.literal("")),
  phone: z.string().trim().max(50).optional(),
  addressLine1: z.string().trim().max(250).optional(),
  city: z.string().trim().max(100).optional(),
  state: z.string().trim().max(50).optional(),
  postalCode: z.string().trim().max(20).optional(),
  notes: z.string().trim().max(5000).optional(),
});

export async function GET() {
  const session = await requireOrganization();
  return Response.json(await db.customer.findMany({ where:{organizationId:session.organizationId}, orderBy:{name:"asc"} }));
}

export async function POST(request: Request) {
  const session = await requireOrganization();
  const parsed = customerSchema.safeParse(await request.json());
  if (!parsed.success) return Response.json({error:parsed.error.issues[0]?.message ?? "Invalid customer."},{status:400});
  const clean = Object.fromEntries(Object.entries(parsed.data).map(([key,value])=>[key,value === "" ? null : value]));
  const customer = await db.customer.create({data:{...clean,organizationId:session.organizationId} as any});
  return Response.json(customer,{status:201});
}
