import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";

export async function GET(_: Request, {params}:{params:Promise<{customerId:string}>}) {
  const session=await requireOrganization(); const {customerId}=await params;
  const customer=await db.customer.findFirst({where:{id:customerId,organizationId:session.organizationId},include:{leads:{orderBy:{updatedAt:"desc"}},projects:{orderBy:{updatedAt:"desc"}},crmActivities:{orderBy:{createdAt:"desc"},include:{actor:{select:{name:true}}}}}});
  return customer?Response.json(customer):Response.json({error:"Customer not found."},{status:404});
}
