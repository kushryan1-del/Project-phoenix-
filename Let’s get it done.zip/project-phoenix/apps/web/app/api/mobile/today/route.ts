import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";

export async function GET() {
  const session = await requireOrganization();
  const start = new Date(); start.setHours(0,0,0,0);
  const end = new Date(start); end.setDate(end.getDate()+1);
  const projects = await db.project.findMany({
    where:{organizationId:session.organizationId,status:{in:["SCHEDULED","ACTIVE_PRODUCTION"]}},
    include:{customer:true,tasks:{where:{status:{not:"DONE"}},orderBy:[{priority:"asc"},{dueAt:"asc"}],take:6},scheduleItems:{where:{startsAt:{gte:start,lt:end}},orderBy:{startsAt:"asc"}}},
    orderBy:{updatedAt:"desc"},take:10
  });
  return Response.json({generatedAt:new Date().toISOString(),projects});
}
