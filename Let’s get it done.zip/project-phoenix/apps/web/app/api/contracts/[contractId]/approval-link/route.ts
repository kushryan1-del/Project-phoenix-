import { db } from "@phoenix/database";
import { requirePermission } from "@/lib/auth/guards";
import { createOpaqueToken, hashToken } from "@/lib/auth/tokens";

export async function POST(request:Request,{params}:{params:Promise<{contractId:string}>}){
  const session=await requirePermission("proposals:write");
  const {contractId}=await params;
  const contract=await db.contract.findFirst({where:{id:contractId,project:{organizationId:session.organizationId}}});
  if(!contract)return Response.json({message:"Contract not found."},{status:404});
  if(["SIGNED","VOID","ARCHIVED"].includes(contract.status))return Response.json({message:"This contract cannot receive a new approval link."},{status:409});
  await db.contractApprovalToken.updateMany({where:{contractId,usedAt:null,revokedAt:null},data:{revokedAt:new Date()}});
  const token=createOpaqueToken(32);
  const expiresAt=new Date(Date.now()+14*24*60*60*1000);
  await db.contractApprovalToken.create({data:{projectId:contract.projectId,contractId,tokenHash:hashToken(token),expiresAt}});
  await db.contract.update({where:{id:contractId},data:{status:"SENT"}});
  await db.activity.create({data:{projectId:contract.projectId,actorId:session.id,type:"DOCUMENT",summary:`Secure approval link created for contract ${contract.contractNumber}.`}});
  const origin=new URL(request.url).origin;
  return Response.json({url:`${origin}/approve/contract/${token}`,expiresAt});
}
