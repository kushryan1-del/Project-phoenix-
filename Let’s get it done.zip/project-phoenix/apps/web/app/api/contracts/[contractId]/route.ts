import { db } from "@phoenix/database";
import { requirePermission } from "@/lib/auth/guards";
import { z } from "zod";

const schema=z.object({status:z.enum(["DRAFT","GENERATED","SENT","VIEWED","SIGNED","VOID","ARCHIVED"])});

export async function GET(_:Request,{params}:{params:Promise<{contractId:string}>}){
  const session=await requirePermission("proposals:read");
  const {contractId}=await params;
  const contract=await db.contract.findFirst({where:{id:contractId,project:{organizationId:session.organizationId}},include:{project:{include:{customer:true}},proposal:true}});
  if(!contract)return Response.json({message:"Contract not found."},{status:404});
  return Response.json({contract});
}

export async function PATCH(request:Request,{params}:{params:Promise<{contractId:string}>}){
  const session=await requirePermission("proposals:write");
  const {contractId}=await params;
  const parsed=schema.safeParse(await request.json());
  if(!parsed.success)return Response.json({message:"Invalid contract status."},{status:400});
  const current=await db.contract.findFirst({where:{id:contractId,project:{organizationId:session.organizationId}}});
  if(!current)return Response.json({message:"Contract not found."},{status:404});
  const contract=await db.contract.update({where:{id:contractId},data:{status:parsed.data.status}});
  await db.activity.create({data:{projectId:contract.projectId,actorId:session.id,type:"DOCUMENT",summary:`Contract ${contract.contractNumber} marked ${parsed.data.status.toLowerCase()}.`}});
  return Response.json({contract});
}
