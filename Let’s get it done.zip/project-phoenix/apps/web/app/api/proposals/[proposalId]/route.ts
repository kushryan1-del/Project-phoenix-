import { db } from "@phoenix/database";
import { requirePermission } from "@/lib/auth/guards";
import { z } from "zod";

const updateSchema=z.object({status:z.enum(["DRAFT","GENERATED","SENT","VIEWED","SIGNED","VOID","ARCHIVED"])});

export async function GET(_:Request,{params}:{params:Promise<{proposalId:string}>}){
  const session=await requirePermission("proposals:read");
  const {proposalId}=await params;
  const proposal=await db.proposal.findFirst({where:{id:proposalId,project:{organizationId:session.organizationId}},include:{project:{include:{customer:true}},estimate:true}});
  if(!proposal)return Response.json({message:"Proposal not found."},{status:404});
  return Response.json({proposal});
}

export async function PATCH(request:Request,{params}:{params:Promise<{proposalId:string}>}){
  const session=await requirePermission("proposals:write");
  const {proposalId}=await params;
  const parsed=updateSchema.safeParse(await request.json());
  if(!parsed.success)return Response.json({message:"Invalid proposal status."},{status:400});
  const current=await db.proposal.findFirst({where:{id:proposalId,project:{organizationId:session.organizationId}}});
  if(!current)return Response.json({message:"Proposal not found."},{status:404});
  const now=new Date();
  const proposal=await db.proposal.update({where:{id:proposalId},data:{
    status:parsed.data.status,
    sentAt:parsed.data.status==="SENT"?now:current.sentAt,
    viewedAt:parsed.data.status==="VIEWED"?now:current.viewedAt,
    signedAt:parsed.data.status==="SIGNED"?now:current.signedAt
  }});
  await db.activity.create({data:{projectId:proposal.projectId,actorId:session.id,type:"DOCUMENT",summary:`Proposal ${proposal.proposalNumber} marked ${parsed.data.status.toLowerCase()}.`}});
  return Response.json({proposal});
}
