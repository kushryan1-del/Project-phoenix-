import { db } from "@phoenix/database";
import { buildProposalModel, defaultProposalTerms } from "@phoenix/documents";
import { requirePermission } from "@/lib/auth/guards";
import { z } from "zod";

const schema=z.object({
  estimateId:z.string().min(1),
  title:z.string().trim().min(2),
  overview:z.string().trim().optional(),
  notes:z.string().trim().optional()
});

export async function GET(){
  const session=await requirePermission("proposals:read");
  const proposals=await db.proposal.findMany({
    where:{project:{organizationId:session.organizationId}},
    include:{project:{include:{customer:true}},estimate:true},
    orderBy:{updatedAt:"desc"}
  });
  return Response.json({proposals});
}

export async function POST(request:Request){
  const session=await requirePermission("proposals:write");
  const parsed=schema.safeParse(await request.json());
  if(!parsed.success)return Response.json({message:"Check the proposal information.",issues:parsed.error.flatten()},{status:400});

  const estimate=await db.estimate.findFirst({
    where:{id:parsed.data.estimateId,organizationId:session.organizationId},
    include:{customer:true,lineItems:{orderBy:{sortOrder:"asc"}},project:true}
  });
  if(!estimate||!estimate.customer)return Response.json({message:"Estimate or customer not found."},{status:404});

  const result=await db.$transaction(async tx=>{
    let project=estimate.project;
    if(!project){
      const count=await tx.project.count({where:{organizationId:session.organizationId}});
      const projectNumber=`RHI-${new Date().getFullYear()}-${String(count+1).padStart(3,"0")}`;
      project=await tx.project.create({data:{
        organizationId:session.organizationId,customerId:estimate.customerId!,projectNumber,
        name:estimate.projectName,projectType:"General",status:"PROPOSAL",
        scope:estimate.lineItems.map(item=>item.description).join("\n"),contractValue:estimate.sellingPrice,
        estimatedCost:Number(estimate.materialCost)+Number(estimate.laborCost)+Number(estimate.otherCost)
      }});
      await tx.estimate.update({where:{id:estimate.id},data:{projectId:project.id,status:"CONVERTED"}});
    }

    const existing=await tx.proposal.count({where:{projectId:project.id}});
    const proposalNumber=`${project.projectNumber}-P${existing+1}`;
    const address=[estimate.customer.addressLine1,estimate.customer.city,estimate.customer.state,estimate.customer.postalCode].filter(Boolean).join(", ");
    const content=buildProposalModel({
      title:parsed.data.title,documentNumber:proposalNumber,customerName:estimate.customer.name,
      customerEmail:estimate.customer.email??undefined,customerPhone:estimate.customer.phone??undefined,
      projectName:estimate.projectName,projectAddress:address||undefined,overview:parsed.data.overview,
      scopeItems:estimate.lineItems.map(item=>item.description),
      lineItems:estimate.lineItems.map(item=>({type:item.type,description:item.description,quantity:Number(item.quantity),unit:item.unit,price:Number(item.total)})),
      investment:Number(estimate.sellingPrice)-Number(estimate.materialTax),materialTax:Number(estimate.materialTax),
      total:Number(estimate.sellingPrice),terms:defaultProposalTerms(),notes:parsed.data.notes
    });
    const proposal=await tx.proposal.create({data:{
      projectId:project.id,estimateId:estimate.id,proposalNumber,version:existing+1,title:parsed.data.title,
      contentJson:content,subtotal:content.investment,materialTax:content.materialTax??0,total:content.total
    }});
    await tx.activity.create({data:{projectId:project.id,actorId:session.id,type:"PROPOSAL_CREATED",summary:`Proposal ${proposalNumber} generated from ${estimate.estimateNumber}.`}});
    return {proposal,project};
  });
  return Response.json(result,{status:201});
}
