import bcrypt from "bcryptjs";
import { db } from "@phoenix/database";
import { resetPasswordSchema } from "@phoenix/auth";
import { hashToken } from "@/lib/auth/tokens";
import { writeAudit } from "@/lib/auth/audit";
import { requestMetadata } from "@/lib/auth/session";

export async function POST(request:Request){
  const meta=await requestMetadata();
  const parsed=resetPasswordSchema.safeParse(await request.json());
  if(!parsed.success) return Response.json({message:"Invalid password reset request.",errors:parsed.error.flatten()},{status:400});
  const record=await db.passwordResetToken.findFirst({
    where:{tokenHash:hashToken(parsed.data.token),usedAt:null,expiresAt:{gt:new Date()}},
    include:{user:true}
  });
  if(!record) return Response.json({message:"This reset link is invalid or expired."},{status:400});
  const passwordHash=await bcrypt.hash(parsed.data.password,12);
  await db.$transaction([
    db.user.update({where:{id:record.userId},data:{passwordHash,failedLoginCount:0,lockedUntil:null}}),
    db.passwordResetToken.update({where:{id:record.id},data:{usedAt:new Date()}}),
    db.authSession.updateMany({where:{userId:record.userId,revokedAt:null},data:{revokedAt:new Date()}})
  ]);
  await writeAudit({
    organizationId:record.user.organizationId,userId:record.userId,action:"PASSWORD_RESET_SUCCESS",
    ipAddress:meta.ipAddress,userAgent:meta.userAgent,summary:"Password reset completed; existing sessions revoked."
  });
  return Response.json({ok:true});
}
