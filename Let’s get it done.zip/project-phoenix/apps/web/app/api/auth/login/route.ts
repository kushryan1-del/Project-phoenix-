import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@phoenix/database";
import { loginSchema } from "@phoenix/auth";
import { authConfig } from "@/lib/auth/config";
import { writeAudit } from "@/lib/auth/audit";
import { requestMetadata } from "@/lib/auth/session";
import { hashToken, signSessionJwt } from "@/lib/auth/tokens";

export async function POST(request:Request){
  const meta=await requestMetadata();
  const parsed=loginSchema.safeParse(await request.json());
  if(!parsed.success) return NextResponse.json({message:"Invalid login request."},{status:400});

  const user=await db.user.findUnique({where:{email:parsed.data.email}});
  const now=new Date();
  const locked=Boolean(user?.lockedUntil && user.lockedUntil>now);
  const valid=Boolean(user?.passwordHash && await bcrypt.compare(parsed.data.password,user.passwordHash));

  if(!user || !user.isActive || locked || !valid){
    if(user && !locked){
      const failures=user.failedLoginCount+1;
      await db.user.update({where:{id:user.id},data:{
        failedLoginCount:failures,
        lockedUntil:failures>=authConfig.maxFailedLogins
          ? new Date(Date.now()+authConfig.lockMinutes*60_000)
          : undefined
      }});
    }
    await writeAudit({
      organizationId:user?.organizationId,userId:user?.id,action:"LOGIN_FAILURE",
      ipAddress:meta.ipAddress,userAgent:meta.userAgent,success:false,
      summary:"Failed sign-in attempt."
    });
    return NextResponse.json({message:"Email or password is incorrect."},{status:401});
  }

  const days=parsed.data.rememberMe?authConfig.rememberedSessionDays:authConfig.sessionDays;
  const expiresAt=new Date(Date.now()+days*86_400_000);
  const pending=await db.authSession.create({
    data:{userId:user.id,tokenHash:"pending-"+crypto.randomUUID(),expiresAt,
      ipAddress:meta.ipAddress??undefined,userAgent:meta.userAgent??undefined}
  });
  const token=await signSessionJwt({
    sessionId:pending.id,userId:user.id,organizationId:user.organizationId,role:user.role
  },expiresAt);
  await db.authSession.update({where:{id:pending.id},data:{tokenHash:hashToken(token)}});
  await db.user.update({where:{id:user.id},data:{lastLoginAt:now,failedLoginCount:0,lockedUntil:null}});
  await writeAudit({
    organizationId:user.organizationId,userId:user.id,action:"LOGIN_SUCCESS",
    ipAddress:meta.ipAddress,userAgent:meta.userAgent,summary:"User signed in."
  });

  const response=NextResponse.json({ok:true,user:{name:user.name,role:user.role}});
  response.cookies.set(authConfig.cookieName,token,{
    httpOnly:true,secure:authConfig.secureCookies,sameSite:"lax",path:"/",expires:expiresAt
  });
  return response;
}
