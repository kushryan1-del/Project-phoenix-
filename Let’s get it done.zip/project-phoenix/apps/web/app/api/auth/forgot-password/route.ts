import { db } from "@phoenix/database";
import { forgotPasswordSchema } from "@phoenix/auth";
import { authConfig } from "@/lib/auth/config";
import { writeAudit } from "@/lib/auth/audit";
import { requestMetadata } from "@/lib/auth/session";
import { createOpaqueToken, hashToken } from "@/lib/auth/tokens";

export async function POST(request:Request){
  const meta=await requestMetadata();
  const parsed=forgotPasswordSchema.safeParse(await request.json());
  if(parsed.success){
    const user=await db.user.findUnique({where:{email:parsed.data.email}});
    if(user?.isActive){
      const token=createOpaqueToken();
      await db.passwordResetToken.create({data:{
        userId:user.id,tokenHash:hashToken(token),
        expiresAt:new Date(Date.now()+authConfig.resetTokenMinutes*60_000)
      }});
      await writeAudit({
        organizationId:user.organizationId,userId:user.id,action:"PASSWORD_RESET_REQUEST",
        ipAddress:meta.ipAddress,userAgent:meta.userAgent,summary:"Password reset requested."
      });
      // Production delivery hook:
      // send `${APP_URL}/reset-password?token=${token}` through the configured email provider.
      if(process.env.NODE_ENV!=="production") console.info("Development reset token:",token);
    }
  }
  return Response.json({message:"If that account exists, password reset instructions will be sent."});
}
