import { getSession } from "@/lib/auth/session";
export async function GET(){
  const session=await getSession();
  return session?Response.json({user:session}):new Response("Unauthorized",{status:401});
}
