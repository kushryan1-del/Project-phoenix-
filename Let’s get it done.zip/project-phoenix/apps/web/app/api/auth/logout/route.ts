import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { db } from "@phoenix/database";
import { authConfig } from "@/lib/auth/config";
import { getSession, requestMetadata } from "@/lib/auth/session";
import { writeAudit } from "@/lib/auth/audit";

export async function POST(){
  const session=await getSession();
  const meta=await requestMetadata();
  if(session){
    await db.authSession.updateMany({where:{id:session.sessionId,userId:session.id},data:{revokedAt:new Date()}});
    await writeAudit({
      organizationId:session.organizationId,userId:session.id,action:"LOGOUT",
      ipAddress:meta.ipAddress,userAgent:meta.userAgent,summary:"User signed out."
    });
  }
  const response=NextResponse.json({ok:true});
  response.cookies.set(authConfig.cookieName,"",{httpOnly:true,path:"/",expires:new Date(0)});
  return response;
}
