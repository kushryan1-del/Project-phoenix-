
import { db } from "@phoenix/database";
import { expenseSchema } from "@phoenix/job-costing";
import { requirePermission,assertOrganizationOwnership } from "@/lib/auth/guards";

export async function POST(request:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session=await requirePermission("projects:write");
  const {projectId}=await params;
  const project=await db.project.findUnique({where:{id:projectId}});
  assertOrganizationOwnership(project,session.organizationId);
  const parsed=expenseSchema.safeParse(await request.json());
  if(!parsed.success) return Response.json({message:"Review the expense.",errors:parsed.error.flatten()},{status:400});
  const expense=await db.projectExpense.create({data:{
    projectId,occurredAt:new Date(parsed.data.occurredAt),description:parsed.data.description,
    category:parsed.data.category,amount:parsed.data.amount,notes:parsed.data.notes
  }});
  return Response.json({expense},{status:201});
}
