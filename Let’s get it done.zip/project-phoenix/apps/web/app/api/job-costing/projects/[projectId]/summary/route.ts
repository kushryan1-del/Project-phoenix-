
import { requirePermission,assertOrganizationOwnership } from "@/lib/auth/guards";
import { getProjectJobCostingSummary } from "@/lib/job-costing/summary";

export async function GET(_:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session=await requirePermission("projects:read");
  const {projectId}=await params;
  const result=await getProjectJobCostingSummary(projectId);
  assertOrganizationOwnership(result?.project,session.organizationId);
  return Response.json(result);
}
