
import { db } from "@phoenix/database";
import { purchaseSchema } from "@phoenix/job-costing";
import { requirePermission,assertOrganizationOwnership } from "@/lib/auth/guards";

export async function POST(request:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session=await requirePermission("projects:write");
  const {projectId}=await params;
  const project=await db.project.findUnique({where:{id:projectId}});
  assertOrganizationOwnership(project,session.organizationId);
  const parsed=purchaseSchema.safeParse(await request.json());
  if(!parsed.success) return Response.json({message:"Review the purchase.",errors:parsed.error.flatten()},{status:400});
  const total=parsed.data.subtotal+parsed.data.salesTax;
  const purchase=await db.projectPurchase.create({data:{
    projectId,purchasedAt:new Date(parsed.data.purchasedAt),supplier:parsed.data.supplier,
    description:parsed.data.description,category:parsed.data.category,
    subtotal:parsed.data.subtotal,salesTax:parsed.data.salesTax,total,
    receiptNumber:parsed.data.receiptNumber,paymentMethod:parsed.data.paymentMethod,
    notes:parsed.data.notes
  }});
  await db.activity.create({data:{projectId,actorId:session.id,type:"NOTE",summary:`Purchase recorded from ${purchase.supplier}: $${Number(purchase.total).toFixed(2)}.`}});
  return Response.json({purchase},{status:201});
}
