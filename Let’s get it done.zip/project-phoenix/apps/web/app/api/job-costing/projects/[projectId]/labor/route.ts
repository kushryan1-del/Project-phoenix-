
import { db } from "@phoenix/database";
import { laborEntrySchema,calculateLaborCost } from "@phoenix/job-costing";
import { requirePermission,assertOrganizationOwnership } from "@/lib/auth/guards";

export async function POST(request:Request,{params}:{params:Promise<{projectId:string}>}) {
  const session=await requirePermission("projects:write");
  const {projectId}=await params;
  const project=await db.project.findUnique({where:{id:projectId}});
  assertOrganizationOwnership(project,session.organizationId);
  const parsed=laborEntrySchema.safeParse(await request.json());
  if(!parsed.success) return Response.json({message:"Review the labor entry.",errors:parsed.error.flatten()},{status:400});
  const costs=calculateLaborCost(parsed.data);
  const entry=await db.projectLaborEntry.create({data:{
    projectId,userId:session.id,workerName:parsed.data.workerName,
    workDate:new Date(parsed.data.workDate),task:parsed.data.task,
    regularHours:parsed.data.regularHours,overtimeHours:parsed.data.overtimeHours,
    hourlyCost:parsed.data.hourlyCost,overtimeMultiplier:parsed.data.overtimeMultiplier,
    laborBurdenPercent:parsed.data.laborBurdenPercent,notes:parsed.data.notes,
    ...costs
  }});
  await db.activity.create({data:{projectId,actorId:session.id,type:"NOTE",summary:`Labor recorded: ${entry.workerName}, ${Number(entry.regularHours)+Number(entry.overtimeHours)} hours.`}});
  return Response.json({entry},{status:201});
}
