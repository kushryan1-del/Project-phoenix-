import Link from "next/link";
import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";

const stages = ["NEW","CONTACTED","SITE_VISIT","ESTIMATING","PROPOSAL_SENT","WON","LOST"] as const;
const usd = new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",maximumFractionDigits:0});

export default async function Leads() {
  const session = await requireOrganization();
  const leads = await db.lead.findMany({where:{organizationId:session.organizationId},include:{customer:true},orderBy:{updatedAt:"desc"}});
  const openValue=leads.filter(l=>!['WON','LOST'].includes(l.stage)).reduce((sum,l)=>sum+Number(l.estimatedValue??0),0);
  const overdue=leads.filter(l=>l.followUpAt&&l.followUpAt<new Date()&&!['WON','LOST'].includes(l.stage)).length;
  return <>
    <header className="topbar"><div><h1>Lead CRM</h1><p>Manage the sales pipeline and keep every follow-up visible.</p></div><Link className="btn" href="/leads/new">Add Lead</Link></header>
    <section className="metric-grid"><article className="metric"><span>Open opportunities</span><strong>{leads.filter(l=>!['WON','LOST'].includes(l.stage)).length}</strong></article><article className="metric"><span>Pipeline value</span><strong>{usd.format(openValue)}</strong></article><article className="metric"><span>Overdue follow-ups</span><strong>{overdue}</strong></article></section>
    <section className="pipeline">
      {stages.map(stage=><article className="pipeline-column" key={stage}><div className="pipeline-heading"><strong>{stage.replaceAll("_"," ")}</strong><span className="badge">{leads.filter(l=>l.stage===stage).length}</span></div><div className="list">
        {leads.filter(l=>l.stage===stage).map(l=><Link className="item lead-card" href={`/leads/${l.id}`} key={l.id}><div className="row"><div><strong>{l.title}</strong><div className="muted">{l.customer?.name??"Unassigned customer"} • {l.source??"Unknown source"}</div></div><span className="badge">{l.estimatedValue?usd.format(Number(l.estimatedValue)):"TBD"}</span></div><div className="muted" style={{marginTop:8}}>Probability: {l.probability}%{l.followUpAt?` • Follow up ${l.followUpAt.toLocaleDateString()}`:""}</div></Link>)}
        {leads.filter(l=>l.stage===stage).length===0&&<p className="muted">No leads</p>}
      </div></article>)}
    </section>
  </>;
}
