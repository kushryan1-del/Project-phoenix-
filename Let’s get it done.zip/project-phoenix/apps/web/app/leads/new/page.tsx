import { db } from "@phoenix/database";
import { LeadForm } from "@/components/crm/LeadForm";
import { requireOrganization } from "@/lib/guards";

export default async function NewLeadPage() {
  const session = await requireOrganization();
  const customers = await db.customer.findMany({ where: { organizationId: session.organizationId }, select: { id: true, name: true }, orderBy: { name: "asc" } });
  return <>
    <header className="topbar"><div><h1>New Lead</h1><p>Add a sales opportunity and schedule the next follow-up.</p></div></header>
    <LeadForm customers={customers} />
  </>;
}
