
import Link from "next/link";
import { db } from "@phoenix/database";
import { requirePermission } from "@/lib/auth/guards";

const money=new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"});

export default async function JobCostingPage() {
  const session=await requirePermission("projects:read");
  const projects=await db.project.findMany({
    where:{organizationId:session.organizationId,status:{not:"ARCHIVED"}},
    include:{customer:true,laborEntries:true,purchases:true,projectExpenses:true,changeOrders:true},
    orderBy:{updatedAt:"desc"}
  });

  return <main className="page-shell">
    <header className="page-header"><div><h1>Job Costing</h1><p>Estimated versus actual project performance.</p></div><span className="badge">RC Milestone 2</span></header>
    <section className="data-card"><table className="data-table"><thead><tr><th>Project</th><th>Contract</th><th>Actual labor</th><th>Actual materials</th><th>Other costs</th><th>Open</th></tr></thead><tbody>
      {projects.map(project=>{
        const labor=project.laborEntries.reduce((s,x)=>s+Number(x.totalCost),0);
        const materials=project.purchases.filter(x=>x.category==="MATERIAL").reduce((s,x)=>s+Number(x.total),0);
        const other=project.purchases.filter(x=>x.category!=="MATERIAL").reduce((s,x)=>s+Number(x.total),0)+project.projectExpenses.reduce((s,x)=>s+Number(x.amount),0);
        return <tr key={project.id}>
          <td><strong>{project.name}</strong><div className="muted">{project.projectNumber} • {project.customer.name}</div></td>
          <td>{money.format(Number(project.contractValue))}</td><td>{money.format(labor)}</td><td>{money.format(materials)}</td><td>{money.format(other)}</td>
          <td><Link className="btn secondary" href={`/job-costing/${project.id}`}>Open</Link></td>
        </tr>;
      })}
    </tbody></table></section>
  </main>;
}
