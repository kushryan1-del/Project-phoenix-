
import { notFound } from "next/navigation";
import { requirePermission,assertOrganizationOwnership } from "@/lib/auth/guards";
import { getProjectJobCostingSummary } from "@/lib/job-costing/summary";
import { JobCostingForms } from "@/components/job-costing/JobCostingForms";

const money=new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"});

function variance(value:number) {
  const sign=value>0?"+":"";
  return `${sign}${money.format(value)}`;
}

export default async function ProjectJobCostingPage({params}:{params:Promise<{projectId:string}>}) {
  const session=await requirePermission("projects:read");
  const {projectId}=await params;
  const result=await getProjectJobCostingSummary(projectId);
  if(!result) notFound();
  assertOrganizationOwnership(result.project,session.organizationId);
  const {project,summary}=result;

  return <main className="page-shell">
    <header className="page-header"><div><h1>{project.name}</h1><p>{project.projectNumber} • Job Costing & Financial Control</p></div><span className={`health-badge ${summary.health.toLowerCase()}`}>{summary.health.replaceAll("_"," ")}</span></header>

    <section className="job-cost-kpis">
      <article className="metric-card"><span>Revenue with approved changes</span><strong>{money.format(summary.revenue)}</strong></article>
      <article className="metric-card"><span>Estimated cost</span><strong>{money.format(summary.estimatedCost)}</strong></article>
      <article className="metric-card"><span>Actual cost</span><strong>{money.format(summary.actualCost)}</strong></article>
      <article className="metric-card"><span>Projected profit</span><strong>{money.format(summary.actualProfit)}</strong></article>
      <article className="metric-card"><span>Projected margin</span><strong>{summary.actualMargin.toFixed(1)}%</strong></article>
      <article className="metric-card"><span>Outstanding invoices</span><strong>{money.format(summary.outstandingInvoices)}</strong></article>
    </section>

    <div className="job-cost-layout">
      <section>
        <article className="data-card">
          <h2>Budget variance</h2>
          <table className="data-table"><thead><tr><th>Category</th><th>Variance</th><th>Status</th></tr></thead><tbody>
            <tr><td>Labor</td><td>{variance(summary.laborVariance)}</td><td>{summary.laborVariance<=0?"Within budget":"Over estimate"}</td></tr>
            <tr><td>Materials</td><td>{variance(summary.materialVariance)}</td><td>{summary.materialVariance<=0?"Within budget":"Over estimate"}</td></tr>
            <tr><td>Other costs</td><td>{variance(summary.otherVariance)}</td><td>{summary.otherVariance<=0?"Within budget":"Over estimate"}</td></tr>
            <tr><td><strong>Total cost</strong></td><td><strong>{variance(summary.costVariance)}</strong></td><td><strong>{summary.health.replaceAll("_"," ")}</strong></td></tr>
          </tbody></table>
        </article>

        <article className="data-card" style={{marginTop:16}}>
          <h2>Labor entries</h2>
          <table className="data-table"><thead><tr><th>Date</th><th>Worker</th><th>Task</th><th>Hours</th><th>Cost</th></tr></thead><tbody>
            {project.laborEntries.map(entry=><tr key={entry.id}><td>{entry.workDate.toLocaleDateString("en-US")}</td><td>{entry.workerName}</td><td>{entry.task}</td><td>{(Number(entry.regularHours)+Number(entry.overtimeHours)).toFixed(2)}</td><td>{money.format(Number(entry.totalCost))}</td></tr>)}
          </tbody></table>
        </article>

        <article className="data-card" style={{marginTop:16}}>
          <h2>Purchases and project expenses</h2>
          <table className="data-table"><thead><tr><th>Date</th><th>Supplier / Description</th><th>Category</th><th>Amount</th></tr></thead><tbody>
            {project.purchases.map(item=><tr key={item.id}><td>{item.purchasedAt.toLocaleDateString("en-US")}</td><td><strong>{item.supplier}</strong><div className="muted">{item.description}</div></td><td>{item.category}</td><td>{money.format(Number(item.total))}</td></tr>)}
            {project.projectExpenses.map(item=><tr key={item.id}><td>{item.occurredAt.toLocaleDateString("en-US")}</td><td>{item.description}</td><td>{item.category}</td><td>{money.format(Number(item.amount))}</td></tr>)}
          </tbody></table>
        </article>
      </section>

      <aside><JobCostingForms projectId={project.id}/></aside>
    </div>
  </main>;
}
