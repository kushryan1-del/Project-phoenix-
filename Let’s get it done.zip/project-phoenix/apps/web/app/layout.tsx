import "./globals.css";
import Link from "next/link";
import type { ReactNode } from "react";
import PwaBootstrap from "@/components/mobile/PwaBootstrap";

export const metadata = { title: "Project Phoenix", description: "Remarkable Home Improvement Operating System", manifest: "/manifest.webmanifest", appleWebApp: { capable: true, title: "Phoenix" } };

const nav = [
  ["Field App","/field"],["Dashboard","/dashboard"],["Customers","/customers"],["Leads","/leads"],
  ["Projects","/projects"],["Job Costing","/job-costing"],["Estimates","/estimates"],["Invoices","/invoices"],
  ["Change Orders","/change-orders"],["Contracts","/contracts"],["Scheduling","/schedule"],["Proposals","/proposals"],["Financial Center","/financial"],["Settings","/settings"]
];

export default function Layout({children}:{children:ReactNode}) {
  return <html lang="en"><body><div className="shell">
    <aside className="sidebar"><div className="brand">PROJECT PHOENIX</div><div className="sub">Remarkable Home Improvement</div>
      <nav className="nav">{nav.map(([label,href])=><Link key={href} href={href}>{label}</Link>)}</nav>
    </aside>
    <main className="content">{children}</main><PwaBootstrap/>
  </div></body></html>;
}
