import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";
const usd=new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"});
export default async function ChangeOrders(){
 const session=await requireOrganization();
 const rows=await db.changeOrder.findMany({where:{project:{organizationId:session.organizationId}},include:{project:{include:{customer:true}}},orderBy:{createdAt:"desc"}});
 const approved=rows.filter(x=>x.status==="APPROVED"||x.status==="COMPLETED").reduce((s,x)=>s+Number(x.addedPrice)+Number(x.materialTax),0);
 return <><header className="topbar"><div><h1>Change Orders</h1><p>Scope additions, added days and customer approvals.</p></div><span className="badge">{usd.format(approved)} Approved</span></header>
 <section className="card"><table className="table"><thead><tr><th>Change Order</th><th>Project</th><th>Added Price</th><th>Added Days</th><th>Status</th></tr></thead><tbody>
 {rows.map(c=><tr key={c.id}><td><strong>CO-{c.number}: {c.title}</strong><div className="muted">{c.description}</div></td><td>{c.project.name}<div className="muted">{c.project.customer.name}</div></td><td>{usd.format(Number(c.addedPrice)+Number(c.materialTax))}</td><td>{c.addedDays}</td><td>{c.status}</td></tr>)}
 </tbody></table></section></>;
}
