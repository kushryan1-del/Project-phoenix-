import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";

const usd = new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",maximumFractionDigits:0});

export default async function Dashboard() {
  const session = await requireOrganization();
  const [projects,leads,customers] = await Promise.all([
    db.project.findMany({where:{organizationId:session.organizationId},include:{customer:true,tasks:true},orderBy:{updatedAt:"desc"},take:5}),
    db.lead.findMany({where:{organizationId:session.organizationId,stage:{notIn:["WON","LOST"]}}}),
    db.customer.count({where:{organizationId:session.organizationId}})
  ]);
  const contractValue = projects.reduce((sum,p)=>sum+Number(p.contractValue),0);
  const estimatedCost = projects.reduce((sum,p)=>sum+Number(p.estimatedCost),0);

  return <>
    <header className="topbar"><div><h1>Executive Dashboard</h1><p>Live PostgreSQL-backed operating view.</p></div><span className="badge">Sprint 4</span></header>
    <section className="grid">
      <article className="card metric"><div className="label">Active Projects</div><div className="value">{projects.length}</div></article>
      <article className="card metric"><div className="label">Open Leads</div><div className="value">{leads.length}</div></article>
      <article className="card metric"><div className="label">Customers</div><div className="value">{customers}</div></article>
      <article className="card metric"><div className="label">Projected Gross Profit</div><div className="value">{usd.format(contractValue-estimatedCost)}</div></article>
      <article className="card wide"><strong>Current Projects</strong><div className="list">
        {projects.map(p=><div className="item" key={p.id}><div className="row"><div><strong>{p.name}</strong><div className="muted">{p.projectNumber} • {p.customer.name} • {p.status.replaceAll("_"," ")}</div></div><span className="badge">{p.progress}%</span></div>
        <div className="progress" style={{marginTop:10}}><span style={{width:`${p.progress}%`}} /></div><div className="muted" style={{marginTop:8}}>Open tasks: {p.tasks.filter(t=>t.status!=="DONE").length} • Next: {p.nextAction ?? "Not set"}</div></div>)}
      </div></article>
      <article className="card side"><strong>Phoenix Priorities</strong><div className="list">
        {leads.slice(0,3).map(l=><div className="item" key={l.id}>Follow up: <strong>{l.title}</strong><div className="muted">{l.stage.replaceAll("_"," ")} • {l.probability}% probability</div></div>)}
        {projects.filter(p=>p.healthScore<90).map(p=><div className="item" key={p.id}>Review project health: <strong>{p.name}</strong><div className="muted">Health score {p.healthScore}</div></div>)}
      </div></article>
    </section>
  </>;
}
