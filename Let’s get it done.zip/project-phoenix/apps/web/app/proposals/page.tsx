import { db } from "@phoenix/database";
import { requirePermission } from "@/lib/auth/guards";

const currency=new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"});
export default async function ProposalsPage(){
  const session=await requirePermission("proposals:read");
  const proposals=await db.proposal.findMany({where:{project:{organizationId:session.organizationId}},include:{project:{include:{customer:true}}},orderBy:{updatedAt:"desc"}});
  return <main className="page-shell"><header className="page-header"><div><h1>Proposals</h1><p>Premium customer proposals generated from approved estimates.</p></div></header>
    <section className="data-card"><table className="data-table"><thead><tr><th>Proposal</th><th>Customer</th><th>Project</th><th>Status</th><th>Total</th><th>Updated</th></tr></thead><tbody>
      {proposals.map(p=><tr key={p.id}><td><a href={`/proposals/${p.id}`}>{p.proposalNumber}</a></td><td>{p.project.customer.name}</td><td>{p.project.name}</td><td><span className="badge">{p.status}</span></td><td>{currency.format(Number(p.total))}</td><td>{p.updatedAt.toLocaleDateString("en-US")}</td></tr>)}
    </tbody></table>{proposals.length===0&&<p className="empty-state">Generate a proposal from an estimate to begin.</p>}</section></main>;
}
