import { notFound } from "next/navigation";
import { db } from "@phoenix/database";
import { requirePermission } from "@/lib/auth/guards";
import { ProposalActions } from "@/components/proposals/ProposalActions";
import { ContractGenerator } from "@/components/contracts/ContractGenerator";

type Content={overview?:string;scopeItems:string[];terms:string[];notes?:string;projectAddress?:string;investment:number;materialTax?:number;total:number};
const currency=new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"});
export default async function ProposalPage({params}:{params:Promise<{proposalId:string}>}){
  const session=await requirePermission("proposals:read");const {proposalId}=await params;
  const proposal=await db.proposal.findFirst({where:{id:proposalId,project:{organizationId:session.organizationId}},include:{project:{include:{customer:true}},estimate:true,contracts:true}});
  if(!proposal)notFound();const content=proposal.contentJson as unknown as Content;
  return <main className="page-shell"><header className="page-header"><div><p className="eyebrow">{proposal.proposalNumber}</p><h1>{proposal.title}</h1><p>{proposal.project.customer.name} · {proposal.project.name}</p></div><ProposalActions proposalId={proposal.id} status={proposal.status}/></header>
    <div className="proposal-layout"><section className="data-card"><h2>Project overview</h2><p>{content.overview||"No overview entered."}</p><h2>Scope of work</h2><ol className="scope-list">{content.scopeItems.map((item,i)=><li key={i}>{item}</li>)}</ol>{content.notes&&<><h2>Project notes</h2><p>{content.notes}</p></>}</section>
    <aside className="data-card proposal-summary"><span className="badge">{proposal.status}</span><h2>Investment</h2><dl><div><dt>Proposal subtotal</dt><dd>{currency.format(Number(proposal.subtotal))}</dd></div><div><dt>Material tax</dt><dd>{currency.format(Number(proposal.materialTax))}</dd></div><div className="total"><dt>Total investment</dt><dd>{currency.format(Number(proposal.total))}</dd></div></dl><h3>Payment schedule</h3><p>40% deposit · 30% progress · 30% final</p><p className="muted">Created {proposal.createdAt.toLocaleDateString("en-US")}</p></aside></div>
    <section className="data-card proposal-terms"><h2>Terms and conditions</h2><ol>{content.terms.map((term,i)=><li key={i}>{term}</li>)}</ol></section>{proposal.contracts.length===0&&<ContractGenerator projectId={proposal.projectId} proposalId={proposal.id} defaultNumber={`${proposal.proposalNumber.replace("PROP","CONT")}`}/>} {proposal.contracts.length>0&&<section className="data-card"><h2>Matching contract</h2><p><a className="btn" href={`/contracts/${proposal.contracts[0].id}`}>Open contract {proposal.contracts[0].contractNumber}</a></p></section>}</main>;
}
