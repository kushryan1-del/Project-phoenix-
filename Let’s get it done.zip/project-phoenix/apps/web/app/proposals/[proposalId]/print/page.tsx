import { notFound } from "next/navigation";
import { db } from "@phoenix/database";
import { requirePermission } from "@/lib/auth/guards";

type Content={brand:{companyName:string;registrationNumber?:string;fullyInsured:boolean};overview?:string;scopeItems:string[];terms:string[];notes?:string;projectAddress?:string;investment:number;materialTax?:number;total:number;generatedAt:string};
const currency=new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"});
export default async function PrintProposal({params}:{params:Promise<{proposalId:string}>}){
 const session=await requirePermission("proposals:read");const {proposalId}=await params;
 const p=await db.proposal.findFirst({where:{id:proposalId,project:{organizationId:session.organizationId}},include:{project:{include:{customer:true}}}});if(!p)notFound();const c=p.contentJson as unknown as Content;
 return <main className="proposal-print"><section className="print-cover"><div className="print-logo">RHI</div><p className="eyebrow">PREMIUM PROJECT PROPOSAL</p><h1>{p.title}</h1><div className="print-rule"/><h2>{p.project.customer.name}</h2><p>{c.projectAddress}</p><p>{p.proposalNumber}</p><footer><strong>{c.brand.companyName}</strong><br/>{c.brand.registrationNumber} · Fully Insured</footer></section>
 <section className="print-page"><h1>Project Overview</h1><p>{c.overview||"This proposal outlines the agreed project scope and investment."}</p><h2>Scope of Work</h2><ol>{c.scopeItems.map((x,i)=><li key={i}>{x}</li>)}</ol>{c.notes&&<><h2>Project Notes</h2><p>{c.notes}</p></>}</section>
 <section className="print-page"><h1>Investment Summary</h1><table><tbody><tr><th>Project subtotal</th><td>{currency.format(Number(p.subtotal))}</td></tr><tr><th>Material tax</th><td>{currency.format(Number(p.materialTax))}</td></tr><tr className="grand"><th>Total investment</th><td>{currency.format(Number(p.total))}</td></tr></tbody></table><h2>Payment Schedule</h2><div className="payment-grid"><div><strong>40%</strong><span>Deposit</span></div><div><strong>30%</strong><span>Progress</span></div><div><strong>30%</strong><span>Final</span></div></div></section>
 <section className="print-page"><h1>Terms & Conditions</h1><ol>{c.terms.map((x,i)=><li key={i}>{x}</li>)}</ol><div className="signatures"><div>Customer Signature<br/><span/></div><div>Date<br/><span/></div><div>Contractor Signature<br/><span/></div><div>Date<br/><span/></div></div></section></main>;
}
