import { db } from "@phoenix/database";
import { requireOrganization } from "@/lib/guards";
const usd=new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"});
export default async function Invoices(){
 const session=await requireOrganization();
 const rows=await db.invoice.findMany({where:{project:{organizationId:session.organizationId}},include:{project:{include:{customer:true}}},orderBy:{issueDate:"desc"}});
 const totals=rows.reduce((a,i)=>({billed:a.billed+Number(i.total),paid:a.paid+Number(i.amountPaid),due:a.due+Number(i.balanceDue)}),{billed:0,paid:0,due:0});
 return <><header className="topbar"><div><h1>Invoices</h1><p>Billing, payments and outstanding balances.</p></div><span className="badge">Cash Flow</span></header>
 <section className="grid"><article className="card metric"><div className="label">Total Billed</div><div className="value">{usd.format(totals.billed)}</div></article><article className="card metric"><div className="label">Collected</div><div className="value">{usd.format(totals.paid)}</div></article><article className="card metric"><div className="label">Outstanding</div><div className="value">{usd.format(totals.due)}</div></article></section>
 <section className="card" style={{marginTop:14}}><table className="table"><thead><tr><th>Invoice</th><th>Customer</th><th>Total</th><th>Paid</th><th>Balance</th><th>Status</th></tr></thead><tbody>
 {rows.map(i=><tr key={i.id}><td><strong>{i.invoiceNumber}</strong><div className="muted">{i.description}</div></td><td>{i.project.customer.name}</td><td>{usd.format(Number(i.total))}</td><td>{usd.format(Number(i.amountPaid))}</td><td>{usd.format(Number(i.balanceDue))}</td><td>{i.status.replaceAll("_"," ")}</td></tr>)}
 </tbody></table></section></>;
}
