import { NextRequest,NextResponse } from "next/server";

const publicPaths=["/login","/forgot-password","/reset-password","/api/auth/login","/api/auth/forgot-password","/api/auth/reset-password"];

export function middleware(request:NextRequest){
  const path=request.nextUrl.pathname;
  if(publicPaths.some(p=>path===p || path.startsWith(p+"/"))) return NextResponse.next();
  if(path.startsWith("/_next")||path==="/favicon.ico") return NextResponse.next();
  const token=request.cookies.get("phoenix_session")?.value;
  if(!token){
    if(path.startsWith("/api/")) return new NextResponse("Unauthorized",{status:401});
    const url=new URL("/login",request.url);
    url.searchParams.set("next",path);
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config={matcher:["/((?!_next/static|_next/image|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)"]};
