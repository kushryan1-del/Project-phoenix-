const CACHE = "phoenix-shell-v1";
const SHELL = ["/field", "/offline", "/manifest.webmanifest"];
self.addEventListener("install", event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL))));
self.addEventListener("activate", event => event.waitUntil(self.clients.claim()));
self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  event.respondWith(fetch(event.request).then(response => {
    const copy = response.clone();
    caches.open(CACHE).then(cache => cache.put(event.request, copy));
    return response;
  }).catch(async () => (await caches.match(event.request)) || (await caches.match("/offline"))));
});
self.addEventListener("sync", event => {
  if (event.tag === "phoenix-sync") event.waitUntil(self.clients.matchAll().then(clients => clients.forEach(client => client.postMessage({type:"PHOENIX_SYNC"}))));
});
