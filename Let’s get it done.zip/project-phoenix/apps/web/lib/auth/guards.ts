import "server-only";
import { redirect } from "next/navigation";
import { hasPermission, type PhoenixRole } from "@phoenix/auth";
import { getSession } from "./session";

export async function requireSession(){
  const session=await getSession();
  if(!session) redirect("/login");
  return session;
}

export async function requirePermission(permission:string){
  const session=await requireSession();
  if(!hasPermission(session.role as PhoenixRole,permission)) redirect("/unauthorized");
  return session;
}

export async function requireOrganization(){
  return requireSession();
}

export async function assertOrganizationOwnership(
  resource:{organizationId:string}|null|undefined,
  organizationId:string
){
  if(!resource || resource.organizationId!==organizationId){
    throw new Error("Resource not found.");
  }
}
