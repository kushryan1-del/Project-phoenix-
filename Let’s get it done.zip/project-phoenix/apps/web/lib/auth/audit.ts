import "server-only";
import { db } from "@phoenix/database";

export async function writeAudit(input:{
  organizationId?:string; userId?:string;
  action:"LOGIN_SUCCESS"|"LOGIN_FAILURE"|"LOGOUT"|"PASSWORD_RESET_REQUEST"|
    "PASSWORD_RESET_SUCCESS"|"USER_CREATED"|"USER_UPDATED"|"ROLE_CHANGED"|
    "SESSION_REVOKED"|"FINANCIAL_WRITE"|"DOCUMENT_GENERATED";
  resourceType?:string; resourceId?:string;
  ipAddress?:string|null; userAgent?:string|null;
  success?:boolean; summary:string; metadata?:Record<string,unknown>;
}){
  await db.auditEvent.create({data:{
    organizationId:input.organizationId,userId:input.userId,action:input.action,
    resourceType:input.resourceType,resourceId:input.resourceId,
    ipAddress:input.ipAddress??undefined,userAgent:input.userAgent??undefined,
    success:input.success??true,summary:input.summary,metadata:input.metadata
  }});
}
