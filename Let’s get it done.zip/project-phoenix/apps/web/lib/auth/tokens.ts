import "server-only";
import { createHash, randomBytes } from "crypto";
import { SignJWT, jwtVerify } from "jose";
import { authConfig } from "./config";

const encoder=new TextEncoder();

export function createOpaqueToken(bytes=32){
  return randomBytes(bytes).toString("base64url");
}

export function hashToken(token:string){
  return createHash("sha256").update(token).digest("hex");
}

export async function signSessionJwt(payload:{sessionId:string;userId:string;organizationId:string;role:string},expiresAt:Date){
  return new SignJWT(payload)
    .setProtectedHeader({alg:"HS256"})
    .setIssuedAt()
    .setExpirationTime(Math.floor(expiresAt.getTime()/1000))
    .sign(encoder.encode(authConfig.secret()));
}

export async function verifySessionJwt(token:string){
  const result=await jwtVerify(token,encoder.encode(authConfig.secret()),{algorithms:["HS256"]});
  return result.payload as unknown as {
    sessionId:string;userId:string;organizationId:string;role:string;exp:number
  };
}
