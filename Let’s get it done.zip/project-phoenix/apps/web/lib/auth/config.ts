import "server-only";

function required(name:string){
  const value=process.env[name];
  if(!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

export const authConfig={
  cookieName:"phoenix_session",
  secret:()=>required("AUTH_SECRET"),
  sessionDays:7,
  rememberedSessionDays:30,
  resetTokenMinutes:30,
  maxFailedLogins:5,
  lockMinutes:15,
  secureCookies:process.env.NODE_ENV==="production"
};
