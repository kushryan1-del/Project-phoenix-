import "server-only";
import { cookies, headers } from "next/headers";
import { db } from "@phoenix/database";
import { authConfig } from "./config";
import { hashToken, verifySessionJwt } from "./tokens";

export type AuthenticatedSession={
  id:string; email:string; name:string; role:string; organizationId:string; sessionId:string;
};

export async function getSession():Promise<AuthenticatedSession|null>{
  const cookieStore=await cookies();
  const token=cookieStore.get(authConfig.cookieName)?.value;
  if(!token) return null;
  try{
    const payload=await verifySessionJwt(token);
    const session=await db.authSession.findFirst({
      where:{
        id:payload.sessionId,tokenHash:hashToken(token),revokedAt:null,
        expiresAt:{gt:new Date()},user:{isActive:true}
      },
      include:{user:true}
    });
    if(!session) return null;
    return {
      id:session.user.id,email:session.user.email,name:session.user.name,
      role:session.user.role,organizationId:session.user.organizationId,sessionId:session.id
    };
  }catch{return null;}
}

export async function requestMetadata(){
  const h=await headers();
  return {
    ipAddress:h.get("x-forwarded-for")?.split(",")[0]?.trim()??h.get("x-real-ip"),
    userAgent:h.get("user-agent")
  };
}
