export type QueuedMutation = {
  id: string;
  url: string;
  method: "POST" | "PUT" | "PATCH" | "DELETE";
  body?: unknown;
  createdAt: string;
  attempts: number;
};

const DB_NAME = "project-phoenix";
const STORE = "mutation-queue";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(STORE, { keyPath: "id" });
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function queueMutation(input: Omit<QueuedMutation, "id" | "createdAt" | "attempts">) {
  const db = await openDb();
  const item: QueuedMutation = { ...input, id: crypto.randomUUID(), createdAt: new Date().toISOString(), attempts: 0 };
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(item);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  return item;
}

export async function pendingMutationCount() {
  const db = await openDb();
  return new Promise<number>((resolve, reject) => {
    const req = db.transaction(STORE).objectStore(STORE).count();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function flushMutationQueue() {
  const db = await openDb();
  const items = await new Promise<QueuedMutation[]>((resolve, reject) => {
    const req = db.transaction(STORE).objectStore(STORE).getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  let synced = 0;
  for (const item of items) {
    try {
      const response = await fetch(item.url, {
        method: item.method,
        headers: { "Content-Type": "application/json", "X-Phoenix-Offline-Id": item.id },
        body: item.body === undefined ? undefined : JSON.stringify(item.body)
      });
      if (!response.ok) throw new Error(`Sync failed: ${response.status}`);
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction(STORE, "readwrite");
        tx.objectStore(STORE).delete(item.id);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
      synced += 1;
    } catch {
      // Keep the mutation queued for the next connection.
    }
  }
  return synced;
}
