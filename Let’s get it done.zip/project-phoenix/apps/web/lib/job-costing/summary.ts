
import { db } from "@phoenix/database";
import { calculateJobCostingSummary } from "@phoenix/job-costing";

export async function getProjectJobCostingSummary(projectId:string) {
  const project = await db.project.findUnique({
    where:{id:projectId},
    include:{
      estimates:{orderBy:{createdAt:"desc"},take:1},
      laborEntries:true,
      purchases:true,
      projectExpenses:true,
      changeOrders:true,
      invoices:true,
      payments:true
    }
  });
  if(!project) return null;

  const estimate = project.estimates[0];
  const approvedChangeOrders = project.changeOrders
    .filter(order=>["APPROVED","COMPLETED"].includes(order.status))
    .reduce((sum,order)=>sum+Number(order.addedPrice)+Number(order.materialTax),0);

  const actualLabor = project.laborEntries.reduce((sum,item)=>sum+Number(item.totalCost),0);
  const actualMaterials = project.purchases
    .filter(item=>item.category==="MATERIAL")
    .reduce((sum,item)=>sum+Number(item.total),0);
  const purchaseOther = project.purchases
    .filter(item=>item.category!=="MATERIAL")
    .reduce((sum,item)=>sum+Number(item.total),0);
  const expenses = project.projectExpenses.reduce((sum,item)=>sum+Number(item.amount),0);
  const invoiced = project.invoices.reduce((sum,item)=>sum+Number(item.total),0);
  const collected = project.payments.reduce((sum,item)=>sum+Number(item.amount),0);

  const summary = calculateJobCostingSummary({
    contractValue:Number(project.contractValue),
    approvedChangeOrders,
    estimatedLabor:estimate?Number(estimate.laborCost):0,
    estimatedMaterials:estimate?Number(estimate.materialCost):0,
    estimatedOther:estimate?Number(estimate.otherCost):Number(project.estimatedCost),
    actualLabor,
    actualMaterials,
    actualOther:purchaseOther+expenses,
    invoiced,
    collected
  });

  return {project,estimate,summary};
}
