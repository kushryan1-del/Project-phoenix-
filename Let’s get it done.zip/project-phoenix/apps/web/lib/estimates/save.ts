
import { calculateEstimate, estimateSchema } from "@phoenix/estimating";

export function parseAndCalculateEstimate(input:unknown) {
  const estimate = estimateSchema.parse(input);
  return {estimate,calculation:calculateEstimate(estimate)};
}
